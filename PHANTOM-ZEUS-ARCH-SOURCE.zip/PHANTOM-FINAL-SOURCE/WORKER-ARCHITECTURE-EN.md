# Phantom Worker Architecture

## Runtime layout

- `DbService`: D1 schema readiness, settings access, and a non-mutating connectivity probe.
- `AuthService`: password hashing, verification, session creation, authorization, and login throttling.
- `ProfileService`: generated links, subscription delivery, and WebSocket handling.
- `ApiController`: authenticated JSON API operations.
- `PanelController`: setup, sign-in, and dashboard page selection.
- `Router`: deterministic request routing.
- `WorkerRuntime`: the single module entry point, request IDs, structured diagnostics, and safe error responses.

The design follows a service/router/controller separation while preserving Phantom's D1 table names and existing API routes. The worker source contains English-only UI and diagnostic text.

## Obfuscation

The release workflow runs Terser and then `javascript-obfuscator` with the `browser-no-eval` target. It does not use `eval()` or `new Function()` at Worker startup. This is intentional for Cloudflare Workers compatibility. Obfuscation raises the effort required to inspect source but is not encryption and cannot guarantee that client-delivered code is impossible to reverse engineer.

## Validation

`tests/worker-smoke.mjs` runs the module under Node 22 with an in-memory SQLite adapter for the D1 API and a stub for Cloudflare TCP sockets. It tests health, setup, session authorization, panel rendering, profile creation/deletion, API state, and subscription generation. It does not test a live Cloudflare deployment or actual TCP/WebSocket connectivity.
