import { connect } from "cloudflare:sockets";

const enc = new TextEncoder();
const dec = new TextDecoder();
const PANEL_NAME = "Phantom";
const DEFAULT_STREAM_TAG = "PHANTOM";
const TLS_PORTS = new Set([443, 2053, 2083, 2087, 2096, 8443]);
const runtimeStats = { active: 0, bytesIn: 0, bytesOut: 0, requests: 0, startedAt: Date.now() };
let schemaPromise;

const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS nova_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS nova_profiles (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    uuid TEXT NOT NULL UNIQUE,
    route_key TEXT NOT NULL UNIQUE,
    protocol TEXT NOT NULL DEFAULT 'both',
    active INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL,
    traffic_limit INTEGER NOT NULL DEFAULT 0,
    traffic_used INTEGER NOT NULL DEFAULT 0
  )`,
  `CREATE INDEX IF NOT EXISTS idx_nova_profiles_route_key ON nova_profiles(route_key)`,
  `CREATE INDEX IF NOT EXISTS idx_nova_profiles_created_at ON nova_profiles(created_at)`
];

const MIGRATIONS = [
  ["traffic_limit", `ALTER TABLE nova_profiles ADD COLUMN traffic_limit INTEGER NOT NULL DEFAULT 0`],
  ["traffic_used", `ALTER TABLE nova_profiles ADD COLUMN traffic_used INTEGER NOT NULL DEFAULT 0`]
];

async function ensureSchema(db) {
  if (!db) throw new Error("D1 binding 'DB' is not configured.");
  if (!schemaPromise) {
    schemaPromise = (async () => {
      for (const sql of SCHEMA) await db.prepare(sql).run();
      const { results = [] } = await db.prepare("PRAGMA table_info(nova_profiles)").all();
      const have = new Set(results.map((c) => c.name));
      for (const [col, sql] of MIGRATIONS) if (!have.has(col)) await db.prepare(sql).run();
    })().catch((error) => {
      schemaPromise = undefined;
      throw error;
    });
  }
  await schemaPromise;
}

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...extraHeaders }
  });
}

async function readJson(request) {
  try { return await request.json(); } catch { return {}; }
}

async function getSetting(db, key, fallback = "") {
  const row = await db.prepare("SELECT value FROM nova_settings WHERE key = ?").bind(key).first();
  return row ? row.value : fallback;
}

async function setSetting(db, key, value) {
  await db.prepare("INSERT OR REPLACE INTO nova_settings (key, value) VALUES (?, ?)").bind(key, String(value)).run();
}

function toB64(bytes) {
  let binary = "";
  for (let i = 0; i < bytes.length; i += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  }
  return btoa(binary);
}

function fromB64(value) {
  const binary = atob(value);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}

function base64Url(bytes) {
  return toB64(bytes).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

function randomBytes(length) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return bytes;
}

function randomHex(length) {
  return [...randomBytes(length)].map((v) => v.toString(16).padStart(2, "0")).join("");
}

async function sha256Hex(value) {
  const hash = await crypto.subtle.digest("SHA-256", enc.encode(value));
  return [...new Uint8Array(hash)].map((v) => v.toString(16).padStart(2, "0")).join("");
}

async function passwordHash(password, saltBytes = randomBytes(16)) {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: saltBytes, iterations: 100000, hash: "SHA-256" }, key, 256);
  return "pbkdf2$100000$" + base64Url(saltBytes) + "$" + base64Url(new Uint8Array(bits));
}

async function verifyPassword(password, stored) {
  try {
    const parts = stored.split("$");
    if (parts.length !== 4 || parts[0] !== "pbkdf2") return false;
    const salt = fromB64(parts[2].replace(/-/g, "+").replace(/_/g, "/"));
    const calculated = await passwordHash(password, salt);
    return constantTimeEqual(calculated, stored);
  } catch { return false; }
}

function constantTimeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function cookieValue(request, name) {
  const cookies = request.headers.get("Cookie") || "";
  const item = cookies.split(";").map((x) => x.trim()).find((x) => x.startsWith(name + "="));
  try { return item ? decodeURIComponent(item.slice(name.length + 1)) : ""; } catch { return ""; }
}

function sessionCookie(token, maxAge = 604800) {
  return `panel_session=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`;
}

async function createSession(db) {
  const token = base64Url(randomBytes(32));
  await setSetting(db, "session_hash", await sha256Hex(token));
  await setSetting(db, "session_expiry", String(Date.now() + 7 * 86400000));
  return token;
}

async function isAuthorized(request, db) {
  const token = cookieValue(request, "panel_session");
  if (!token) return false;
  const [expected, expiry] = await Promise.all([
    getSetting(db, "session_hash"),
    getSetting(db, "session_expiry", "0")
  ]);
  if (!expected || Number(expiry) < Date.now()) return false;
  return constantTimeEqual(await sha256Hex(token), expected);
}

function safeTag(value) {
  const tag = String(value || DEFAULT_STREAM_TAG).toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, 32);
  return tag || DEFAULT_STREAM_TAG;
}

function parseLines(value) {
  return String(value || "").split(/[\r\n,;]+/).map((x) => x.trim()).filter(Boolean).slice(0, 100);
}

function parsePorts(value) {
  const raw = parseLines(value || "443");
  const ports = raw.map((p) => Number(p)).filter((p) => Number.isInteger(p) && p >= 1 && p <= 65535);
  return [...new Set(ports)].slice(0, 12).length ? [...new Set(ports)].slice(0, 12) : [443];
}

function parseLimit(value) {
  const gb = Number(value);
  return Number.isFinite(gb) && gb > 0 ? Math.min(Math.round(gb * 1073741824), 1e15) : 0;
}

function cleanEndpoint(value) {
  let host = String(value || "").trim();
  host = host.replace(/^https?:\/\//i, "").replace(/\/$/, "");
  if (host.startsWith("[")) {
    const end = host.indexOf("]");
    if (end < 0) return "";
    host = host.slice(1, end);
  } else if (host.split(":").length === 2) {
    host = host.replace(/:\d+$/, "");
  }
  if (!host || /[\s/?#@]/.test(host)) return "";
  return host;
}

function formatEndpoint(host) {
  return host.includes(":") && !host.startsWith("[") ? `[${host}]` : host;
}

async function currentSettings(db) {
  const [edgeHosts, ports, streamTag] = await Promise.all([
    getSetting(db, "edge_hosts", ""),
    getSetting(db, "ports", "443"),
    getSetting(db, "stream_tag", DEFAULT_STREAM_TAG)
  ]);
  return { edgeHosts, ports, streamTag: safeTag(streamTag) };
}

function buildLinks(user, workerHost, settings) {
  const endpoints = parseLines(settings.edgeHosts).map(cleanEndpoint).filter(Boolean);
  if (!endpoints.length) endpoints.push(workerHost);
  let ports = parsePorts(settings.ports);
  // Prefer 443 first for lower latency on CDN
  ports = [...ports].sort((a, b) => (a === 443 ? -1 : b === 443 ? 1 : a - b));
  const tag = safeTag(settings.streamTag);
  const path = `/stream/${tag}/${user.route_key}`;
  const pathParam = encodeURIComponent(path);
  const links = [];
  for (const endpoint of endpoints) {
    for (const port of ports) {
      const security = TLS_PORTS.has(port) ? "tls" : "none";
      // SNI/Host must be the Worker domain (CF cert), not the edge IP
      const tls = security === "tls"
        ? `&sni=${encodeURIComponent(workerHost)}&fp=chrome`
        : "";
      const common = `type=ws&security=${security}&path=${pathParam}&host=${encodeURIComponent(workerHost)}`;
      const label = encodeURIComponent(String(user.name || "nova").slice(0, 16));
      const at = `${formatEndpoint(endpoint)}:${port}`;
      if (user.protocol === "vless" || user.protocol === "both") {
        links.push(`vless://${user.uuid}@${at}?encryption=none&${common}${tls}#${label}`);
      }
      if (user.protocol === "trojan" || user.protocol === "both") {
        links.push(`trojan://${user.uuid}@${at}?${common}${tls}#${label}`);
      }
    }
  }
  return links;
}

async function handleSubscription(url, env) {
  let routeKey = "";
  try { routeKey = decodeURIComponent(url.pathname.slice("/sub/".length)).split("/")[0]; } catch { return new Response("Not Found", { status: 404 }); }
  if (!routeKey || routeKey.length > 40) return new Response("Not Found", { status: 404 });
  const user = await env.DB.prepare("SELECT * FROM nova_profiles WHERE route_key = ? AND active = 1").bind(routeKey).first();
  if (!user) return new Response("Not Found", { status: 404 });
  const settings = await currentSettings(env.DB);
  const content = buildLinks(user, url.hostname, settings).join("\n");
  const bytes = enc.encode(content);
  const body = toB64(bytes);
  return new Response(body, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-store, no-cache, must-revalidate",
      "Access-Control-Allow-Origin": "*",
      "profile-update-interval": "12",
      "Subscription-Userinfo": `upload=0; download=${Number(user.traffic_used) || 0}; total=${Number(user.traffic_limit) || 0}; expire=0`
    }
  });
}

function uuidBytes(uuid) {
  const hex = String(uuid || "").replace(/-/g, "");
  if (!/^[a-f0-9]{32}$/i.test(hex)) return null;
  const out = new Uint8Array(16);
  for (let i = 0; i < 16; i++) out[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return out;
}

function equalBytes(a, b) {
  if (!a || !b || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

function sha224Hex(message) {
  const rr = (n, x) => (x >>> n) | (x << (32 - n));
  const ch = (x, y, z) => (x & y) ^ (~x & z);
  const maj = (x, y, z) => (x & y) ^ (x & z) ^ (y & z);
  const s0 = (x) => rr(2, x) ^ rr(13, x) ^ rr(22, x);
  const s1 = (x) => rr(6, x) ^ rr(11, x) ^ rr(25, x);
  const g0 = (x) => rr(7, x) ^ rr(18, x) ^ (x >>> 3);
  const g1 = (x) => rr(17, x) ^ rr(19, x) ^ (x >>> 10);
  const k = [
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
  ];
  const h = [0xc1059ed8,0x367cd507,0x3070dd17,0xf70e5939,0xffc00b31,0x68581511,0x64f98fa7,0xbefa4fa4];
  const input = enc.encode(message);
  const bitLength = input.length * 8;
  const paddedLength = Math.ceil((input.length + 9) / 64) * 64;
  const padded = new Uint8Array(paddedLength);
  padded.set(input);
  padded[input.length] = 0x80;
  const view = new DataView(padded.buffer);
  view.setUint32(paddedLength - 4, bitLength >>> 0, false);
  view.setUint32(paddedLength - 8, Math.floor(bitLength / 0x100000000), false);
  const w = new Uint32Array(64);
  for (let offset = 0; offset < paddedLength; offset += 64) {
    for (let t = 0; t < 16; t++) w[t] = view.getUint32(offset + t * 4, false);
    for (let t = 16; t < 64; t++) w[t] = (g1(w[t - 2]) + w[t - 7] + g0(w[t - 15]) + w[t - 16]) >>> 0;
    let [a,b,c,d,e,f,g,hh] = h;
    for (let t = 0; t < 64; t++) {
      const t1 = (hh + s1(e) + ch(e,f,g) + k[t] + w[t]) >>> 0;
      const t2 = (s0(a) + maj(a,b,c)) >>> 0;
      hh = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    h[0]=(h[0]+a)>>>0; h[1]=(h[1]+b)>>>0; h[2]=(h[2]+c)>>>0; h[3]=(h[3]+d)>>>0;
    h[4]=(h[4]+e)>>>0; h[5]=(h[5]+f)>>>0; h[6]=(h[6]+g)>>>0; h[7]=(h[7]+hh)>>>0;
  }
  return h.slice(0, 7).map((x) => x.toString(16).padStart(8, "0")).join("");
}

function parseVless(data, user) {
  if (data.length < 18) return { needMore: true };
  if (data[0] !== 0) return { error: "bad-vless-version" };
  const id = uuidBytes(user.uuid);
  if (!equalBytes(data.subarray(1, 17), id)) return { error: "bad-vless-auth" };
  let offset = 18 + data[17];
  if (data.length < offset + 4) return { needMore: true };
  const command = data[offset];
  if (command !== 1) return { error: "unsupported-vless-command" };
  const port = (data[offset + 1] << 8) | data[offset + 2];
  offset += 3;
  const parsed = parseAddress(data, offset);
  if (parsed.needMore) return parsed;
  if (parsed.error) return parsed;
  return { host: parsed.host, port, payload: data.slice(parsed.next), response: new Uint8Array([data[0], 0]) };
}

function parseAddress(data, offset) {
  if (data.length <= offset) return { needMore: true };
  const type = data[offset++];
  let host;
  if (type === 1) {
    if (data.length < offset + 4) return { needMore: true };
    host = [...data.slice(offset, offset + 4)].join(".");
    offset += 4;
  } else if (type === 2) {
    if (data.length < offset + 1) return { needMore: true };
    const length = data[offset++];
    if (data.length < offset + length) return { needMore: true };
    host = dec.decode(data.slice(offset, offset + length));
    offset += length;
  } else if (type === 3) {
    if (data.length < offset + 16) return { needMore: true };
    const parts = [];
    for (let i = 0; i < 16; i += 2) parts.push(((data[offset + i] << 8) | data[offset + i + 1]).toString(16));
    host = parts.join(":");
    offset += 16;
  } else {
    return { error: "bad-address-type" };
  }
  return { host, next: offset };
}

function parseTrojan(data, user) {
  if (data.length < 59) return { needMore: true };
  const expected = sha224Hex(user.uuid);
  const received = dec.decode(data.slice(0, 56));
  if (!constantTimeEqual(received, expected) || data[56] !== 13 || data[57] !== 10) return { error: "bad-trojan-auth" };
  const command = data[58];
  if (command !== 1) return { error: "unsupported-trojan-command" };
  let offset = 59;
  if (data.length <= offset) return { needMore: true };
  const type = data[offset++];
  let host;
  if (type === 1) {
    if (data.length < offset + 4 + 4) return { needMore: true };
    host = [...data.slice(offset, offset + 4)].join(".");
    offset += 4;
  } else if (type === 3) {
    if (data.length < offset + 1) return { needMore: true };
    const length = data[offset++];
    if (data.length < offset + length + 4) return { needMore: true };
    host = dec.decode(data.slice(offset, offset + length));
    offset += length;
  } else if (type === 4) {
    if (data.length < offset + 16 + 4) return { needMore: true };
    const parts = [];
    for (let i = 0; i < 16; i += 2) parts.push(((data[offset + i] << 8) | data[offset + i + 1]).toString(16));
    host = parts.join(":");
    offset += 16;
  } else {
    return { error: "bad-trojan-address-type" };
  }
  const port = (data[offset] << 8) | data[offset + 1];
  offset += 2;
  if (data.length < offset + 2) return { needMore: true };
  if (data[offset] !== 13 || data[offset + 1] !== 10) return { error: "bad-trojan-ending" };
  offset += 2;
  return { host, port, payload: data.slice(offset), response: null };
}

function asBytes(data) {
  if (data instanceof ArrayBuffer) return new Uint8Array(data);
  if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  if (typeof data === "string") return enc.encode(data);
  return null;
}

function concatBytes(a, b) {
  const result = new Uint8Array(a.length + b.length);
  result.set(a, 0);
  result.set(b, a.length);
  return result;
}

function handleWebSocket(request, env, ctx, user) {
  if ((request.headers.get("Upgrade") || "").toLowerCase() !== "websocket") {
    return new Response("WebSocket upgrade required", { status: 426, headers: { Upgrade: "websocket" } });
  }
  const pair = new WebSocketPair();
  const client = pair[0];
  const server = pair[1];
  server.accept();
  server.binaryType = "arraybuffer";
  runtimeStats.active++;

  let pending = new Uint8Array(0);
  let connected = false;
  let closed = false;
  let socket;
  let writer;
  let inputChain = Promise.resolve();
  let unflushed = 0;

  const flushUsage = async () => {
    const bytes = unflushed;
    if (bytes < 1) return;
    unflushed = 0;
    try {
      await env.DB.prepare("UPDATE nova_profiles SET traffic_used = COALESCE(traffic_used,0) + ? WHERE id = ?").bind(bytes, user.id).run();
      const limit = Number(user.traffic_limit) || 0;
      if (limit > 0) {
        const row = await env.DB.prepare("SELECT traffic_used, active FROM nova_profiles WHERE id = ?").bind(user.id).first();
        if (!row || Number(row.active) !== 1 || Number(row.traffic_used) >= limit) await finish(1008, "profile unavailable");
      }
    } catch (error) {
      unflushed = Math.min(unflushed + bytes, 8 * 1024 * 1024);
    }
  };
  const usageTimer = setInterval(flushUsage, 20000);

  const finish = async (code = 1000, reason = "closed") => {
    if (closed) return;
    closed = true;
    clearInterval(usageTimer);
    runtimeStats.active = Math.max(0, runtimeStats.active - 1);
    try { if (writer) await writer.close(); } catch {}
    try { if (socket) await socket.close(); } catch {}
    try { server.close(code, reason); } catch {}
    if (ctx && ctx.waitUntil) ctx.waitUntil(flushUsage()); else await flushUsage();
  };

  const fail = async (error) => {
    console.error("PHANTOM stream:", error && error.message ? error.message : String(error));
    await finish(1011, "upstream error");
  };

  async function establish(parsed) {
    if (!parsed.host || !Number.isInteger(parsed.port) || parsed.port < 1 || parsed.port > 65535) {
      throw new Error("invalid destination");
    }
    socket = connect({ hostname: parsed.host, port: parsed.port }, { allowHalfOpen: true });
    await socket.opened;
    writer = socket.writable.getWriter();
    if (parsed.response) server.send(parsed.response);
    if (parsed.payload && parsed.payload.length) {
      await writer.write(parsed.payload);
      runtimeStats.bytesIn += parsed.payload.length;
      unflushed += parsed.payload.length;
    }
    connected = true;
    const reader = socket.readable.getReader();
    const relay = (async () => {
      try {
        while (!closed) {
          const item = await reader.read();
          if (item.done) break;
          if (item.value && item.value.length) {
            server.send(item.value);
            runtimeStats.bytesOut += item.value.length;
            unflushed += item.value.length;
          }
        }
      } finally {
        try { reader.releaseLock(); } catch {}
        await finish(1000, "upstream closed");
      }
    })();
    if (ctx && ctx.waitUntil) ctx.waitUntil(relay.catch(fail));
    else relay.catch(fail);
  }

  async function onMessage(raw) {
    if (closed) return;
    const bytes = asBytes(raw);
    if (!bytes) throw new Error("unsupported websocket frame");
    if (connected) {
      await writer.write(bytes);
      runtimeStats.bytesIn += bytes.length;
      unflushed += bytes.length;
      return;
    }
    pending = concatBytes(pending, bytes);
    if (pending.length > 16384) throw new Error("handshake too large");
    let parsed;
    const proto = user.protocol;
    const mayVless = proto === "both" || proto === "vless";
    const mayTrojan = proto === "both" || proto === "trojan";
    if (pending.length && pending[0] === 0 && mayVless) parsed = parseVless(pending, user);
    else if (mayTrojan) parsed = parseTrojan(pending, user);
    else throw new Error("protocol disabled");
    if (parsed && parsed.needMore) return;
    if (!parsed || parsed.error) throw new Error(parsed && parsed.error ? parsed.error : "invalid handshake");
    await establish(parsed);
    pending = new Uint8Array(0);
  }

  server.addEventListener("message", (event) => {
    inputChain = inputChain.then(() => onMessage(event.data)).catch(fail);
  });
  server.addEventListener("close", () => finish(1000, "client closed"));
  server.addEventListener("error", () => finish(1011, "websocket error"));
  return new Response(null, { status: 101, webSocket: client });
}

const HOME_HTML = `<!doctype html><html lang="en" dir="ltr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#070b16"><title>PHANTOM | Private Gateway</title><style>
:root{color-scheme:dark;--bg:#070b16;--line:#213454;--muted:#91a5c8;--blue:#70aaff}*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:radial-gradient(ellipse at 50% 8%,#172b50 0,#0a1222 42%,#050812 100%);color:#eef4ff;font-family:Inter,Segoe UI,Arial,sans-serif}.shell{width:min(520px,100%);text-align:center}.card{padding:42px 36px;border:1px solid #263d65;border-radius:24px;background:linear-gradient(145deg,#111d33f2,#0a1221f5);box-shadow:0 30px 100px #0009}.mark{width:72px;height:72px;margin:0 auto 22px;border-radius:23px;display:grid;place-items:center;background:linear-gradient(145deg,#428cff,#7652ea);font-size:32px;box-shadow:0 12px 34px #376ce055}.eyebrow{font-size:10px;font-weight:bold;letter-spacing:5px;color:#81b2ff}h1{font-size:25px;margin:16px 0 12px}.desc{font-size:13px;line-height:2.2;color:var(--muted);margin:0 auto 28px;max-width:390px}.route{display:inline-block;padding:3px 10px;border:1px solid #294875;border-radius:8px;background:#0b1930;color:#8ebaff;font-weight:bold;direction:ltr}.go{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:15px;border-radius:12px;background:linear-gradient(90deg,#287cff,#6559ed);color:white;text-decoration:none;font-size:14px;font-weight:bold;box-shadow:0 10px 28px #3c67d533;transition:transform .2s,filter .2s}.go:hover{transform:translateY(-2px);filter:brightness(1.1)}.hint{margin-top:20px;color:#7389ae;font-size:11px}.foot{margin-top:22px;color:#5e7398;font-size:10px;letter-spacing:3px}@media(max-width:480px){.card{padding:32px 22px}h1{font-size:22px}}
</style></head><body><main class="shell"><section class="card"><div class="mark">✦</div><div class="eyebrow">P H A N T O M / PRIVATE GATEWAY</div><h1>Personal Connection Gateway</h1><p class="desc">To open the management panel, visit <span class="route">/panel</span> on your Worker URL, or use the button below.</p><a class="go" href="/panel">Sign In <span aria-hidden="true">←</span></a><div class="hint">Management access requires your private password.</div></section><div class="foot">PHANTOM · PERSONAL CONNECTION CONSOLE</div></main></body></html>`;

const LOGIN_HTML = `<!doctype html><html lang="en" dir="ltr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PHANTOM | Sign In</title><style>
:root{color-scheme:dark;--bg:#070b16;--panel:#0d1527;--line:#1b2a48;--muted:#93a4c4;--blue:#62a4ff;--green:#32d69a}*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(ellipse at 50% 12%,#142545 0,#080e1c 44%,#050812 100%);color:#e9f0ff;font-family:Inter,Segoe UI,Arial,sans-serif;display:grid;place-items:center;padding:24px}.card{width:min(440px,100%);padding:34px;border:1px solid #23385e;border-radius:22px;background:linear-gradient(145deg,#101b31ed,#0a1120f5);box-shadow:0 28px 90px #0008}.logo{height:62px;width:62px;border-radius:20px;display:grid;place-items:center;margin:0 auto 20px;background:linear-gradient(145deg,#3e7cff,#7546e8);font-size:28px;box-shadow:0 12px 32px #315be955}.eyebrow{text-align:center;color:#78aaff;font-size:11px;letter-spacing:4px;font-weight:bold}h1{text-align:center;font-size:22px;margin:13px 0 9px}.sub{text-align:center;color:var(--muted);font-size:13px;line-height:2;margin:0 0 24px}label{display:block;color:#b8c6df;font-size:12px;margin-bottom:8px}input{width:100%;border:1px solid #263b60;border-radius:12px;background:#081122;color:#fff;padding:14px;font:inherit;outline:none}input:focus{border-color:#5797ff;box-shadow:0 0 0 3px #5797ff20}button{width:100%;border:0;border-radius:12px;padding:14px;margin-top:16px;background:linear-gradient(90deg,#2d7cff,#5b61ec);color:white;font: bold 14px Inter,Segoe UI,Arial;cursor:pointer}#msg{min-height:22px;color:#ff8794;font-size:12px;text-align:center;margin-top:12px}.foot{text-align:center;margin-top:24px;color:#5e7398;font-size:10px;letter-spacing:2px}
/* PHANTOM / SECURE ACCESS visual layer */
body{background:radial-gradient(ellipse at 14% 0%,rgba(13,130,158,.22),transparent 36%),radial-gradient(ellipse at 88% 18%,rgba(76,76,174,.18),transparent 32%),linear-gradient(180deg,#050912,#080e19 54%,#050912)}
body:before{content:"";position:fixed;inset:0;pointer-events:none;background-image:linear-gradient(rgba(96,140,180,.045) 1px,transparent 1px),linear-gradient(90deg,rgba(96,140,180,.045) 1px,transparent 1px);background-size:34px 34px;mask-image:linear-gradient(to bottom,#000,transparent 88%)}
.card{position:relative;border-color:rgba(84,214,255,.24);background:linear-gradient(145deg,rgba(12,27,43,.97),rgba(7,15,28,.98));box-shadow:0 28px 100px rgba(0,0,0,.62),0 0 40px rgba(26,154,188,.07);backdrop-filter:blur(16px)}
.logo{background:linear-gradient(145deg,#087f9d,#5557cf);border:1px solid rgba(116,226,255,.42);box-shadow:0 0 30px rgba(45,191,224,.18)}
.eyebrow{color:#68dfff;letter-spacing:3px}
input:focus{border-color:#54d6ff;box-shadow:0 0 0 3px rgba(84,214,255,.11)}
button{background:linear-gradient(105deg,#087f9d,#315ce4);box-shadow:0 8px 24px rgba(34,131,190,.18)}
button:hover{filter:brightness(1.12)}
:focus-visible{outline:2px solid #54d6ff;outline-offset:3px}
@media(prefers-reduced-motion:reduce){*,*:before,*:after{transition-duration:.01ms!important;animation-duration:.01ms!important}}
</style></head><body><main class="card"><div class="logo">✦</div><div class="eyebrow">P H A N T O M / PRIVATE GATEWAY</div><h1>__TITLE__</h1><p class="sub">__DESC__</p><form id="auth"><label for="pass">__LABEL__</label><input id="pass" type="password" minlength="8" autocomplete="__AUTO__" required placeholder="At least 8 characters"><button id="submit">__BUTTON__</button></form><div id="msg"></div><div class="foot">PERSONAL CONNECTION CONSOLE</div></main><script>
const form=document.getElementById('auth'),msg=document.getElementById('msg'),btn=document.getElementById('submit');form.addEventListener('submit',async e=>{e.preventDefault();btn.disabled=true;msg.textContent='Checking...';try{const r=await fetch('__ENDPOINT__',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({password:document.getElementById('pass').value,k:((location.hash.match(/k=([A-Za-z0-9]+)/)||[])[1]||'')})});const raw=await r.text();let d;try{d=JSON.parse(raw)}catch{const detail=(raw||'Empty response').replace(/\\s+/g,' ').slice(0,180);throw new Error('Invalid API response (HTTP '+r.status+'): '+detail)}if(!r.ok)throw new Error(d.error||('HTTP error '+r.status));location.href='/panel'}catch(e){msg.textContent=e.message;btn.disabled=false}});
</script></body></html>`;

const DASHBOARD_HTML = `<!doctype html><html lang="en" dir="ltr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PHANTOM | Control Panel</title><style>
:root{color-scheme:dark;--bg:#070b15;--surface:#0d1526;--surface2:#101c31;--line:#1c2c49;--text:#eaf1ff;--muted:#8fa2c4;--blue:#69a7ff;--green:#32d69a;--orange:#ff9b52;--red:#ff647e;--purple:#9b79ff}*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at 50% -10%,#122345 0,#080e1b 42%,#060a13 100%);color:var(--text);font-family:Inter,Segoe UI,Arial,sans-serif;min-height:100vh}.top{height:76px;border-bottom:1px solid #1b2b47;background:#0a1222e8;backdrop-filter:blur(14px);display:flex;align-items:center;justify-content:space-between;padding:0 max(24px,calc((100vw - 1380px)/2));position:sticky;top:0;z-index:5}.brand{display:flex;align-items:center;gap:12px;font-weight:bold;letter-spacing:4px;font-size:18px}.brandmark{width:38px;height:38px;border-radius:13px;background:linear-gradient(145deg,#458dff,#7557e8);display:grid;place-items:center;font-size:20px;box-shadow:0 8px 24px #345bba55}.brand small{display:block;color:#7187ad;font-size:9px;letter-spacing:2px;margin-top:4px}.toolbar{display:flex;gap:8px}.ic{height:38px;width:38px;border:1px solid #263b60;border-radius:13px;background:#101b30;color:#9eb8e3;cursor:pointer;font-size:16px}.ic:hover{border-color:#6ba7ff;color:white}.wrap{width:min(1380px,calc(100% - 36px));margin:34px auto 70px}.heading{display:flex;align-items:end;justify-content:space-between;margin-bottom:24px;gap:18px}.kicker{color:#71a9ff;font-size:10px;letter-spacing:3px;font-weight:bold}.heading h1{margin:8px 0 0;font-size:24px}.heading p{color:var(--muted);font-size:12px;margin:9px 0 0}.live{display:flex;align-items:center;gap:8px;color:#9eb4d5;font-size:11px;border:1px solid #1b3153;padding:9px 13px;border-radius:99px;background:#0d172a}.dot{width:7px;height:7px;border-radius:50%;background:var(--green);box-shadow:0 0 12px var(--green)}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:22px}.stat{background:linear-gradient(145deg,#101b30,#0c1424);border:1px solid var(--line);border-radius:17px;padding:19px;min-height:120px;position:relative;overflow:hidden}.stat:after{content:"";position:absolute;width:110px;height:110px;left:-25px;bottom:-55px;border-radius:50%;background:var(--glow,#448cff);opacity:.09;filter:blur(18px)}.statHead{display:flex;align-items:center;justify-content:space-between;color:#a9bad6;font-size:11px}.symbol{display:grid;place-items:center;width:32px;height:32px;border-radius:11px;background:#192846;color:var(--accent,var(--blue));font-size:17px}.value{font-size:25px;font-weight:bold;margin:15px 0 5px;color:var(--accent,var(--blue));direction:ltr;text-align:right}.hint{font-size:10px;color:#7387a9}.grid{display:grid;grid-template-columns:minmax(0,1.55fr) minmax(290px,.75fr);gap:18px}.box{border:1px solid var(--line);background:linear-gradient(145deg,#0e1729,#0a1221);border-radius:18px;overflow:hidden}.boxhead{padding:18px 20px;border-bottom:1px solid #1a2a45;display:flex;align-items:center;justify-content:space-between;gap:12px}.boxhead h2{margin:0;font-size:14px}.muted{color:var(--muted);font-size:11px}.actions{display:flex;gap:8px;flex-wrap:wrap}.btn{border:1px solid #2b4774;border-radius:11px;background:#142544;color:#dceaff;padding:10px 14px;font:12px Inter,Segoe UI,Arial;cursor:pointer}.btn.primary{background:linear-gradient(90deg,#286ef0,#695ce5);border:0;color:white;font-weight:bold}.btn.green{border-color:#1d805f;color:#60e6b1;background:#0b261f}.btn.red{border-color:#713245;color:#ff8a9d;background:#28131d}.btn:hover{filter:brightness(1.14)}.searchrow{display:flex;gap:10px;padding:14px 18px;border-bottom:1px solid #172641}.searchrow input,.field input,.field select,.field textarea{width:100%;border:1px solid #263b60;background:#091326;border-radius:10px;padding:11px 12px;color:#eaf1ff;font:12px Tahoma;outline:none}.searchrow input:focus,.field input:focus,.field textarea:focus{border-color:#5897ff}.list{padding:8px 14px 14px}.user{display:grid;grid-template-columns:minmax(150px,1.2fr) .7fr .7fr auto;gap:12px;align-items:center;padding:15px 8px;border-bottom:1px solid #17243b}.user:last-child{border-bottom:0}.userName{font-weight:bold;font-size:12px}.userMeta{color:#8195b8;font-size:10px;margin-top:6px;direction:ltr;text-align:right}.pill{display:inline-flex;align-items:center;gap:6px;border:1px solid #2b4165;background:#111f37;padding:6px 9px;border-radius:99px;font-size:10px;color:#b9cceb}.pill.good{border-color:#1d654f;background:#0d271f;color:#5de2ad}.pill.off{border-color:#683143;background:#2b1620;color:#ff8b9e}.userActions{display:flex;gap:6px;justify-content:end;flex-wrap:wrap}.mini{border:1px solid #29416b;border-radius:9px;background:#101e35;color:#b7cff7;padding:7px 9px;font:10px Inter,Segoe UI,Arial;cursor:pointer}.mini:hover{border-color:#73aaff;color:white}.empty{padding:35px 12px;text-align:center;color:#8094b7;font-size:12px}.sidebody{padding:18px}.field{margin-bottom:14px}.field label{display:block;color:#a7badb;font-size:11px;margin-bottom:8px}.field textarea{min-height:125px;resize:vertical;line-height:1.7;direction:ltr;text-align:left}.note{border:1px solid #284167;background:#101e35;border-radius:12px;padding:13px;color:#9db4d8;font-size:10px;line-height:1.9}.footnote{color:#607596;font-size:10px;text-align:center;margin-top:20px}.modal{position:fixed;inset:0;z-index:99999;background:#020611c9;backdrop-filter:blur(7px);display:none;place-items:center;padding:18px;z-index:20}.modal.open{display:grid}.dialog{width:min(490px,100%);border:1px solid #304a75;background:#0d172a;border-radius:19px;padding:22px;box-shadow:0 30px 90px #000a}.dialogHead{display:flex;align-items:center;justify-content:space-between;margin-bottom:18px}.dialogHead h3{margin:0;font-size:16px}.close{border:1px solid #2c4266;background:#13223c;color:#abc1e6;border-radius:9px;padding:6px 10px;cursor:pointer}.dialog .field{margin-bottom:13px}.dialogFoot{display:flex;gap:8px;margin-top:18px}.dialogFoot button{flex:1}#phantom-rain{position:fixed;inset:0;width:100%;height:100%;z-index:0;pointer-events:none;opacity:.45}body{position:relative}header.top,.wrap,.modal{position:relative;z-index:5}.toast{position:fixed;bottom:22px;left:22px;background:#10253d;border:1px solid #365986;color:#e5efff;padding:12px 16px;border-radius:12px;font-size:12px;z-index:30;box-shadow:0 12px 35px #0008}.hidden{display:none!important}
@media(max-width:980px){.grid{grid-template-columns:1fr}.stats{grid-template-columns:repeat(2,1fr)}}@media(max-width:620px){.top{padding:0 14px}.toolbar{gap:4px}.ic{width:33px;height:33px}.wrap{width:calc(100% - 22px);margin-top:23px}.heading{align-items:start;flex-direction:column}.stats{gap:9px}.stat{padding:13px;min-height:108px}.value{font-size:20px}.user{grid-template-columns:1fr 1fr;gap:8px}.userActions{grid-column:1/-1;justify-content:start}.boxhead{padding:15px}.searchrow{padding:12px}.brand{font-size:15px}}
.userExtra{grid-column:1/-1;display:flex;align-items:center;gap:18px;flex-wrap:wrap;padding:12px 14px;margin-top:2px;border:1px solid #1b2c49;border-radius:14px;background:#0b1424}.qr{width:96px;height:96px;flex:none;border-radius:10px;overflow:hidden;background:#fff;cursor:zoom-in;box-shadow:0 6px 20px #0006}.qr svg,#qrBig svg{display:block;width:100%;height:100%}.ring{position:relative;width:96px;height:96px;flex:none}.ring svg{width:100%;height:100%;transform:rotate(-90deg)}.ring .track{stroke:#1a2a46}.ring .bar{transition:stroke-dashoffset .6s}.ringText{position:absolute;inset:0;display:grid;place-items:center;font-size:16px;font-weight:bold;direction:ltr}.usageInfo{min-width:0;font-size:11px;color:#9db1d3;line-height:2.1}.usageInfo b{color:#eaf1ff;direction:ltr;display:inline-block}

/* PHANTOM / CONTROL ROOM visual layer */
:root{--blue:#54d6ff;--green:#63f0b3;--purple:#8b8cff;--line:#20334d;--muted:#92a7c3}
body{background:radial-gradient(ellipse at 12% -8%,rgba(24,111,143,.20),transparent 34%),radial-gradient(ellipse at 88% 4%,rgba(77,71,177,.16),transparent 32%),linear-gradient(180deg,#050912 0%,#080e19 54%,#050912 100%)}
body:after{content:"";position:fixed;inset:0;z-index:0;pointer-events:none;background-image:linear-gradient(rgba(96,140,180,.045) 1px,transparent 1px),linear-gradient(90deg,rgba(96,140,180,.045) 1px,transparent 1px);background-size:34px 34px;mask-image:linear-gradient(to bottom,#000 0%,transparent 86%)}
header.top{background:rgba(6,13,25,.86);border-bottom-color:rgba(84,214,255,.18);box-shadow:0 12px 40px rgba(0,0,0,.18)}
.brand{letter-spacing:2.6px}.brandmark{background:linear-gradient(145deg,#087f9d,#5557cf);border:1px solid rgba(116,226,255,.42);box-shadow:0 0 26px rgba(45,191,224,.18)}
.kicker{color:#68dfff}.live{border-color:rgba(84,214,255,.22);background:rgba(8,25,39,.75);letter-spacing:.4px}.dot{box-shadow:0 0 14px var(--green)}.dot.offline{background:var(--red);box-shadow:0 0 14px var(--red)}
.stat,.box{transition:transform .18s ease,border-color .18s ease,box-shadow .18s ease}.stat:hover,.box:hover{border-color:rgba(84,214,255,.32);box-shadow:0 18px 48px rgba(0,0,0,.22)}
.stat{background:linear-gradient(145deg,rgba(15,29,47,.96),rgba(8,17,30,.96))}.box{background:linear-gradient(145deg,rgba(12,24,40,.97),rgba(7,15,27,.98))}
.value{font-family:ui-monospace,Consolas,monospace;letter-spacing:.3px}.btn,.mini,.ic,.close{transition:transform .16s ease,border-color .16s ease,filter .16s ease}.btn:active,.mini:active,.ic:active{transform:translateY(1px)}
.btn.primary{background:linear-gradient(105deg,#087f9d,#315ce4);box-shadow:0 8px 24px rgba(34,131,190,.18)}
.btn.green{background:rgba(8,47,39,.78)}.mini{background:rgba(13,30,50,.92)}
.searchrow input:focus,.field input:focus,.field textarea:focus,.field select:focus{border-color:#54d6ff;box-shadow:0 0 0 3px rgba(84,214,255,.09)}
.user{transition:background .16s ease}.user:hover{background:rgba(21,48,73,.20)}.userExtra{border-color:rgba(84,214,255,.13);background:rgba(6,17,30,.78)}
.toast{border-color:rgba(84,214,255,.35);background:rgba(8,27,43,.96);backdrop-filter:blur(16px)}
:focus-visible{outline:2px solid #54d6ff;outline-offset:3px}
@media(prefers-reduced-motion:reduce){*,*:before,*:after{scroll-behavior:auto!important;animation-duration:.01ms!important;transition-duration:.01ms!important}}
</style></head><body><canvas id="phantom-rain" aria-hidden="true"></canvas><script>(function(){var c=document.getElementById("phantom-rain");if(!c)return;var x=c.getContext("2d"),w,h,drops=[],sp=[];function sz(){w=c.width=innerWidth;h=c.height=innerHeight;var n=Math.max(1,Math.floor(w/16));drops=Array(n);sp=Array(n);for(var i=0;i<n;i++){drops[i]=Math.random()*-60;sp[i]=.3+Math.random()*.85}}sz();addEventListener("resize",sz);var g="01{}[]<>/$#";function fr(){x.fillStyle="rgba(7,11,21,.18)";x.fillRect(0,0,w,h);x.font="12px monospace";for(var i=0;i<drops.length;i++){x.fillStyle=Math.random()>.97?"#d8fff0":"#157a50";x.fillText(g[Math.floor(Math.random()*g.length)],i*16,drops[i]*16);if(drops[i]*16>h&&Math.random()>.975)drops[i]=0;drops[i]+=sp[i]}requestAnimationFrame(fr)}if(!matchMedia("(prefers-reduced-motion: reduce)").matches)fr()})();</script>
<header class="top"><div class="brand"><div class="brandmark">✦</div><div>P H A N T O M<small>PERSONAL GATEWAY</small></div></div><div class="toolbar"><button class="ic" title="Refresh" onclick="loadState()">↻</button><button class="ic" title="Settings" onclick="document.getElementById('settings').scrollIntoView({behavior:'smooth'})">⚙</button><button class="ic" title="Sign out" onclick="logout()">⇥</button></div></header>
<main class="wrap"><section class="heading"><div><div class="kicker">CONTROL CENTER / PRIVATE USE</div><h1>Connection Control Dashboard</h1><p>Manage profiles, generate VLESS and Trojan links, and configure connection routes.</p></div><div class="live" aria-live="polite"><span class="dot" id="apiDot"></span><span id="apiStatus">Checking service status...</span></div></section>
<section class="stats"><article class="stat" style="--accent:#75aaff;--glow:#4b8cff"><div class="statHead"><span>Total Profiles</span><span class="symbol">◈</span></div><div class="value" id="totalUsers">—</div><div class="hint">Profiles stored in D1</div></article><article class="stat" style="--accent:#42dfaa;--glow:#2ed59a"><div class="statHead"><span>Active Profiles</span><span class="symbol">ϟ</span></div><div class="value" id="activeUsers">—</div><div class="hint">Available to clients</div></article><article class="stat" style="--accent:#ffad67;--glow:#ff9145"><div class="statHead"><span>Live Connections</span><span class="symbol">⌁</span></div><div class="value" id="liveConnections">0</div><div class="hint">Current Worker instance only</div></article><article class="stat" style="--accent:#b49aff;--glow:#9272ff"><div class="statHead"><span>Transferred Traffic</span><span class="symbol">⇄</span></div><div class="value" id="traffic">0 MB</div><div class="hint">Combined recorded profile usage</div></article></section>
<section class="grid"><article class="box"><div class="boxhead"><div><h2>Profiles</h2><div class="muted" id="listHint">Configuration List</div></div><div class="actions"><button class="btn primary" onclick="openModal()">＋ Create Profile</button></div></div><div class="searchrow"><input id="search" placeholder="Search by name or UUID..." oninput="renderUsers()"><button class="btn" onclick="loadState()">Refresh</button></div><div class="list" id="users"><div class="empty">Loading data...</div></div></article>
<aside class="box" id="settings"><div class="boxhead"><div><h2>Output Settings</h2><div class="muted">Connection parameters and subscription links</div></div><span class="symbol">⚙</span></div><div class="sidebody"><div class="field"><label>Edge IPs or hostnames (one per line)</label><textarea id="edgeHosts" placeholder="Example:&#10;104.21.x.x&#10;104.16.x.x"></textarea></div><div class="field"><label>Ports (comma-separated)</label><input id="ports" value="443" placeholder="443,2053,2083"></div><div class="field"><label>WebSocket Route Tag</label><input id="streamTag" value="PHANTOM" maxlength="32"></div><button class="btn primary" style="width:100%" onclick="saveSettings()">Save Settings</button><div class="note" style="margin-top:15px">The Worker hostname is used for Host and SNI. Add any edge hostnames you control above. Use port 443 for TLS endpoints. Existing usage counters can be reset per profile.</div></div></aside></section>
<div class="footnote">PHANTOM PERSONAL PANEL · D1 STORAGE · WEBSOCKET STREAM</div></main>
<div class="modal" id="modal"><div class="dialog"><div class="dialogHead"><h3>Create New Profile</h3><button class="close" onclick="closeModal()">✕</button></div><div class="field"><label>Profile Name</label><input id="newName" maxlength="32" placeholder="Example: Main Phone" onkeydown="if(event.key==='Enter')createUser()"></div><div class="field"><label>Protocol</label><select id="newProtocol"><option value="both">Both: VLESS + Trojan</option><option value="vless">VLESS only</option><option value="trojan">Trojan only</option></select></div><div class="field"><label>Traffic Limit (GB, 0 = Unlimited)</label><input id="newLimit" type="number" min="0" step="0.1" value="0"></div><div class="note">Each profile receives a unique identifier. Share links are generated after creation.</div><div class="dialogFoot"><button class="btn primary" id="createBtn" onclick="createUser()">Create and Save</button><button class="btn" onclick="closeModal()">Cancel</button></div></div></div><div class="modal" id="qrModal" onclick="if(event.target===this)this.classList.remove('open')"><div class="dialog" style="width:min(340px,100%);text-align:center"><div class="dialogHead"><h3 id="qrTitle"></h3><button class="close" onclick="document.getElementById('qrModal').classList.remove('open')">✕</button></div><div id="qrBig" style="background:#fff;border-radius:14px;overflow:hidden"></div><div class="note" style="margin-top:14px;direction:ltr;word-break:break-all" id="qrLink"></div></div></div><div id="toast" class="toast hidden"></div>
<script>
let state={users:[],settings:{}};
function toast(s){const t=document.getElementById('toast');t.textContent=s;t.classList.remove('hidden');clearTimeout(window.__toastTimer);window.__toastTimer=setTimeout(()=>t.classList.add('hidden'),2600)}
async function api(path,options){const ac=new AbortController();const tm=setTimeout(()=>ac.abort(),25000);try{const r=await fetch(path,Object.assign({headers:{'Content-Type':'application/json'},signal:ac.signal},options||{}));const d=await r.json().catch(()=>({}));if(r.status===401){location.href='/panel';throw new Error(d.error||'Session expired')}if(!r.ok)throw new Error(d.error||('HTTP '+r.status));return d}catch(e){throw e.name==='AbortError'?new Error('The server did not respond. Please try again.'):e}finally{clearTimeout(tm)}}
let filled=false;
function setApiStatus(online){const label=document.getElementById('apiStatus'),dot=document.getElementById('apiDot');if(label)label.textContent=online?'API + D1 ONLINE':'API + D1 OFFLINE';if(dot)dot.classList.toggle('offline',!online)}
async function loadState(force){try{state=await api('/api/state');setApiStatus(true);document.getElementById('totalUsers').textContent=state.stats.total;document.getElementById('activeUsers').textContent=state.stats.active;document.getElementById('liveConnections').textContent=state.stats.connections;document.getElementById('traffic').textContent=fmtBytes(state.stats.trafficBytes);if(force||!filled){document.getElementById('edgeHosts').value=state.settings.edgeHosts||'';document.getElementById('ports').value=state.settings.ports||'443';document.getElementById('streamTag').value=state.settings.streamTag||'PHANTOM';filled=true}document.getElementById('listHint').textContent=state.users.length+' Saved profiles';renderUsers()}catch(e){setApiStatus(false);toast(e.message)}}
function esc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function renderUsers(){const q=(document.getElementById('search').value||'').toLowerCase();const rows=state.users.filter(u=>(u.name+' '+u.uuid).toLowerCase().includes(q));const root=document.getElementById('users');if(!rows.length){root.innerHTML='<div class="empty">'+(state.users.length?'No matching profiles found.':'No profiles yet. Use Create Profile to get started.')+'</div>';return}root.innerHTML=rows.map(u=>{const proto=u.protocol==='both'?'VLESS + Trojan':u.protocol.toUpperCase();const aq=s=>JSON.stringify(s).replace(/"/g,'"');return '<div class="user"><div><div class="userName">'+esc(u.name)+'</div><div class="userMeta">'+esc(u.uuid.slice(0,18))+'…</div></div><div><span class="pill">'+proto+'</span></div><div><span class="pill '+(u.active?'good':'off')+'">'+(u.active?'● Active':'● Inactive')+'</span></div><div class="userActions"><button class="mini" onclick="copyText('+aq(u.subscription)+')">Copy Subscription</button><button class="mini" onclick="copyText('+aq(u.links.join('\n'))+')">Copy Configs</button><button class="mini" onclick="toggleUser('+aq(u.id)+','+(u.active?0:1)+')">'+(u.active?'Disable':'Enable')+'</button><button class="mini" onclick="deleteUser('+aq(u.id)+')">Delete</button><button class="mini" onclick="setLimit('+aq(u.id)+')">Limit</button><button class="mini" onclick="resetUsage('+aq(u.id)+')">Reset Usage</button></div><div class="userExtra">'+usageBlock(u)+'</div></div>'}).join('')}
function qrSvg(text){
const EC=[[10,[[1,16]]],[16,[[1,28]]],[26,[[1,44]]],[18,[[2,32]]],[24,[[2,43]]],[16,[[4,27]]],[18,[[4,31]]],[22,[[2,38],[2,39]]],[22,[[3,36],[2,37]]],[26,[[4,43],[1,44]]]];
const AL=[[],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50]];
const bytes=Array.from(new TextEncoder().encode(text));let v=0,cap=0;
for(let i=0;i<10;i++){cap=EC[i][1].reduce((a,b)=>a+b[0]*b[1],0);if(4+(i<9?8:16)+8*bytes.length<=8*cap){v=i+1;break}}
if(!v)return '';
const bits=[];const put=(val,n)=>{for(let i=n-1;i>=0;i--)bits.push((val>>i)&1)};
put(4,4);put(bytes.length,v<10?8:16);bytes.forEach(b=>put(b,8));
for(let i=0;i<4&&bits.length<cap*8;i++)bits.push(0);
while(bits.length%8)bits.push(0);
const data=[];for(let i=0;i<bits.length;i+=8){let b=0;for(let j=0;j<8;j++)b=(b<<1)|bits[i+j];data.push(b)}
for(let p=0;data.length<cap;p++)data.push(p%2?17:236);
const exp=[],log=[];let x=1;for(let i=0;i<255;i++){exp[i]=x;log[x]=i;x<<=1;if(x&256)x^=285}
const mul=(a,b)=>a&&b?exp[(log[a]+log[b])%255]:0;
const rs=(d,n)=>{let g=[1];for(let i=0;i<n;i++){const ng=new Array(g.length+1).fill(0);for(let j=0;j<g.length;j++){ng[j]^=g[j];ng[j+1]^=mul(g[j],exp[i])}g=ng}const r=new Array(n).fill(0);for(const c of d){const f=c^r.shift();r.push(0);if(f)for(let j=0;j<n;j++)r[j]^=mul(g[j+1],f)}return r};
const ecn=EC[v-1][0],blocks=[];let pos=0;
EC[v-1][1].forEach(([cnt,len])=>{for(let i=0;i<cnt;i++){const d=data.slice(pos,pos+len);pos+=len;blocks.push({d,e:rs(d,ecn)})}});
const out=[];const maxLen=Math.max(...blocks.map(b=>b.d.length));
for(let i=0;i<maxLen;i++)blocks.forEach(b=>{if(i<b.d.length)out.push(b.d[i])});
for(let i=0;i<ecn;i++)blocks.forEach(b=>out.push(b.e[i]));
const n=17+4*v,m=[],f=[];for(let i=0;i<n;i++){m.push(new Array(n).fill(false));f.push(new Array(n).fill(false))}
const set=(c,r,val)=>{if(c>=0&&r>=0&&c<n&&r<n){m[r][c]=val;f[r][c]=true}};
for(let i=0;i<n;i++){set(6,i,i%2==0);set(i,6,i%2==0)}
const finder=(cx,cy)=>{for(let dy=-4;dy<=4;dy++)for(let dx=-4;dx<=4;dx++){const d=Math.max(Math.abs(dx),Math.abs(dy));set(cx+dx,cy+dy,d!=2&&d!=4)}};
finder(3,3);finder(n-4,3);finder(3,n-4);
const ap=AL[v-1];
for(let i=0;i<ap.length;i++)for(let j=0;j<ap.length;j++){if((i==0&&j==0)||(i==0&&j==ap.length-1)||(i==ap.length-1&&j==0))continue;for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++)set(ap[i]+dx,ap[j]+dy,Math.max(Math.abs(dx),Math.abs(dy))!=1)}
const fmt=mask=>{let r=mask;for(let i=0;i<10;i++)r=(r<<1)^((r>>>9)*0x537);const b=((mask<<10)|r)^0x5412;const g=i=>((b>>>i)&1)==1;
for(let i=0;i<=5;i++)set(8,i,g(i));set(8,7,g(6));set(8,8,g(7));set(7,8,g(8));for(let i=9;i<15;i++)set(14-i,8,g(i));
for(let i=0;i<8;i++)set(n-1-i,8,g(i));for(let i=8;i<15;i++)set(8,n-15+i,g(i));set(8,n-8,true)};
fmt(0);
if(v>=7){let r=v;for(let i=0;i<12;i++)r=(r<<1)^((r>>>11)*0x1F25);const b=(v<<12)|r;for(let i=0;i<18;i++){const c=((b>>>i)&1)==1,a=n-11+i%3,q=Math.floor(i/3);set(a,q,c);set(q,a,c)}}
let k=0;
for(let right=n-1;right>=1;right-=2){if(right==6)right=5;for(let vert=0;vert<n;vert++)for(let j=0;j<2;j++){const cx=right-j,up=((right+1)&2)==0,cy=up?n-1-vert:vert;if(!f[cy][cx]&&k<out.length*8){m[cy][cx]=((out[k>>>3]>>>(7-(k&7)))&1)==1;k++}}}
const mk=[(x,y)=>(x+y)%2==0,(x,y)=>y%2==0,(x,y)=>x%3==0,(x,y)=>(x+y)%3==0,(x,y)=>(Math.floor(x/3)+Math.floor(y/2))%2==0,(x,y)=>x*y%2+x*y%3==0,(x,y)=>(x*y%2+x*y%3)%2==0,(x,y)=>((x+y)%2+x*y%3)%2==0];
const apply=t=>{for(let y=0;y<n;y++)for(let c=0;c<n;c++)if(!f[y][c]&&mk[t](c,y))m[y][c]=!m[y][c]};
const pen=()=>{let p=0,dark=0;const rows=m.map(r=>r.map(c=>c?1:0).join(''));const cols=[];for(let c=0;c<n;c++)cols.push(m.map(r=>r[c]?1:0).join(''));
for(const s of rows.concat(cols)){const runs=s.match(/0+|1+/g);for(const r of runs)if(r.length>=5)p+=r.length-2;p+=(s.match(/10111010000|00001011101/g)||[]).length*40}
for(let y=0;y<n-1;y++)for(let c=0;c<n-1;c++)if(m[y][c]==m[y][c+1]&&m[y][c]==m[y+1][c]&&m[y][c]==m[y+1][c+1])p+=3;
for(const r of m)for(const c of r)if(c)dark++;p+=Math.floor(Math.abs(dark*20-n*n*10)/(n*n))*10;return p};
let best=0,bp=1e9;
for(let t=0;t<8;t++){apply(t);fmt(t);const p=pen();if(p<bp){bp=p;best=t}apply(t)}
apply(best);fmt(best);
const q=3,s=n+q*2;let d='';
for(let y=0;y<n;y++){let c=0;while(c<n){if(!m[y][c]){c++;continue}let e=c;while(e<n&&m[y][e])e++;d+='M'+(c+q)+' '+(y+q)+'h'+(e-c)+'v1h-'+(e-c)+'z';c=e}}
return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '+s+' '+s+'" shape-rendering="crispEdges"><rect width="'+s+'" height="'+s+'" fill="#fff"/><path d="'+d+'" fill="#000"/></svg>';
}
const qrCache={};
function qrFor(t){
  t=String(t||'');
  if(!t) return '<div style="padding:8px;font-size:11px">empty</div>';
  if(qrCache[t]) return qrCache[t];
  let local='';
  try { local=qrSvg(t)||''; } catch(e) { local=''; }
  if(local.indexOf('<svg')===0){ qrCache[t]=local; return local; }
  qrCache[t]='<div style="padding:10px;font-size:11px;color:#222;background:#fff;border-radius:8px">QR code could not be generated (link is too long). Copy the link instead.</div>';
  return qrCache[t];
}
function normalizeNumberInput(value){return String(value==null?'':value).trim()}
function fmtBytes(n){n=Number(n)||0;const u=['B','KB','MB','GB','TB'];let i=0;while(n>=1024&&i<4){n/=1024;i++}return (i?n.toFixed(2):String(n))+' '+u[i]}
function makeRid(){return (window.crypto&&crypto.randomUUID)?crypto.randomUUID():('r'+Date.now().toString(36)+Math.random().toString(36).slice(2,10))}
let newRid=makeRid(),creating=false;
function usageBlock(u){const used=u.used||0,limit=u.limit||0;const p=limit>0?Math.min(1,used/limit):0;const col=!limit?'#69a7ff':p<.7?'#32d69a':p<.9?'#ff9b52':'#ff647e';const C=263.89;const pct=!limit?'∞':(p>0&&p<.01?'&lt;1%':Math.round(p*100)+'%');return '<div class="qr" title="View QR code" onclick="showQr('+esc(JSON.stringify(u.id))+')">'+qrFor((u.links&&u.links[0])||u.subscription)+'</div><div class="ring"><svg viewBox="0 0 100 100"><circle class="track" cx="50" cy="50" r="42" fill="none" stroke-width="10"/><circle class="bar" cx="50" cy="50" r="42" fill="none" stroke="'+col+'" stroke-width="10" stroke-linecap="round" stroke-dasharray="'+C+'" stroke-dashoffset="'+(C*(1-p)).toFixed(2)+'"/></svg><div class="ringText" style="color:'+col+'">'+pct+'</div></div><div class="usageInfo"><div>Used: <b>'+fmtBytes(used)+'</b></div><div>Total Limit: <b>'+(limit?fmtBytes(limit):'Unlimited')+'</b></div>'+(limit?'<div>Remaining: <b>'+fmtBytes(Math.max(0,limit-used))+'</b></div>':'')+'</div>'}
function showQr(id){
  const u=state.users.find(x=>x.id===id);
  if(!u)return;
  // Clients like v2rayNG import best from a single share link (vless/trojan), not only sub URL
  const primary=(u.links&&u.links[0])?u.links[0]:u.subscription;
  document.getElementById('qrTitle').textContent=u.name;
  document.getElementById('qrBig').innerHTML=qrFor(primary);
  document.getElementById('qrLink').textContent=primary;
  const modal=document.getElementById('qrModal');
  modal.classList.add('open');
  modal.style.display='grid';
}
async function setLimit(id){const u=state.users.find(x=>x.id===id);const v=prompt('Total limit in GB (0 = unlimited):',u&&u.limit?String(Math.round(u.limit/1073741824*100)/100):'0');if(v===null)return;const gb=Number(normalizeNumberInput(v));if(!isFinite(gb)||gb<0){toast('Invalid number');return}try{await api('/api/users/'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify({limitGb:gb})});await loadState();toast('Limit updated')}catch(e){toast(e.message)}}
async function resetUsage(id){if(!confirm('Reset this profile usage to zero?'))return;try{await api('/api/users/'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify({resetUsage:true})});await loadState();toast('Usage reset')}catch(e){toast(e.message)}}
async function copyText(text){try{await navigator.clipboard.writeText(text);toast('Copied')}catch(e){try{const t=document.createElement('textarea');t.value=text;t.style.position='fixed';t.style.opacity='0';document.body.appendChild(t);t.select();const ok=document.execCommand('copy');document.body.removeChild(t);toast(ok?'Copied':'Clipboard copy is unavailable')}catch(e2){toast('Clipboard copy failed. Check browser permissions.')}}}
function openModal(){document.getElementById('modal').classList.add('open');document.getElementById('newName').focus()}
function closeModal(){document.getElementById('modal').classList.remove('open')}
async function createUser(){if(creating)return;const name=document.getElementById('newName').value.trim();const protocol=document.getElementById('newProtocol').value;const limitGb=Number(normalizeNumberInput(document.getElementById('newLimit').value))||0;if(!name){toast('Enter a profile name');return}creating=true;const btn=document.getElementById('createBtn');btn.disabled=true;btn.textContent='Creating...';try{await api('/api/users',{method:'POST',body:JSON.stringify({name,protocol,limitGb,rid:newRid})});newRid=makeRid();document.getElementById('newName').value='';document.getElementById('newLimit').value='0';closeModal();await loadState();toast('Profile created')}catch(e){toast(e.message)}finally{creating=false;btn.disabled=false;btn.textContent='Create and Save'}}
async function toggleUser(id,active){try{await api('/api/users/'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify({active})});await loadState();toast('Status updated')}catch(e){toast(e.message)}}
async function deleteUser(id){if(!confirm('Delete this profile? Its links will stop working.'))return;try{await api('/api/users/'+encodeURIComponent(id),{method:'DELETE'});await loadState();toast('Profile deleted')}catch(e){toast(e.message)}}
async function saveSettings(){try{await api('/api/settings',{method:'POST',body:JSON.stringify({edgeHosts:document.getElementById('edgeHosts').value,ports:document.getElementById('ports').value,streamTag:document.getElementById('streamTag').value})});await loadState(true);toast('Settings saved')}catch(e){toast(e.message)}}
async function logout(){try{await api('/api/auth/logout',{method:'POST',body:'{}'});location.href='/'}catch(e){toast(e.message)}}
loadState(true);setInterval(()=>loadState(),30000);
</script></body></html>`;

function renderAuthPage(mode) {
  const setup = mode === "setup";
  return LOGIN_HTML
    .replace("__TITLE__", setup ? "Panel Setup" : "Sign In")
    .replace("__DESC__", setup ? "Choose a strong password for your personal panel." : "Enter your panel password to access the dashboard.")
    .replace("__LABEL__", setup ? "New Password" : "Password")
    .replace("__AUTO__", setup ? "new-password" : "current-password")
    .replace("__BUTTON__", setup ? "Set Password & Sign In" : "Sign In")
    .replace("__ENDPOINT__", setup ? "/api/auth/setup" : "/api/auth/login");
}

async function handleApi(request, url, env) {
  const path = url.pathname;
  if (path === "/api/auth/setup" && request.method === "POST") {
    if (await getSetting(env.DB, "panel_password_hash")) return json({ error: "The panel password has already been configured." }, 409);
    const { password = "", k = "" } = await readJson(request);
    const setupKey = typeof env.SETUP_KEY === "string" ? env.SETUP_KEY : "";
    if (!setupKey || !constantTimeEqual(String(k), setupKey)) return json({ error: "Invalid setup key. Open the panel from the app." }, 403);
    if (typeof password !== "string" || password.length < 8) return json({ error: "Password must be at least 8 characters." }, 400);
    await setSetting(env.DB, "panel_password_hash", await passwordHash(password));
    const token = await createSession(env.DB);
    return json({ success: true }, 200, { "Set-Cookie": sessionCookie(token) });
  }
  if (path === "/api/auth/login" && request.method === "POST") {
    const ip = request.headers.get("CF-Connecting-IP") || "unknown";
    const guard = await loginGuard(env.DB, ip);
    if (guard.count >= MAX_LOGIN_FAILS) return json({ error: "Too many attempts. Try again in 15 minutes." }, 429);
    const { password = "" } = await readJson(request);
    const stored = await getSetting(env.DB, "panel_password_hash");
    if (!stored || !(await verifyPassword(String(password), stored))) {
      await setSetting(env.DB, guard.key, `${guard.count + 1}:${Date.now()}`);
      return json({ error: "Incorrect password." }, 401);
    }
    if (guard.count) await env.DB.prepare("DELETE FROM nova_settings WHERE key = ?").bind(guard.key).run();
    const token = await createSession(env.DB);
    return json({ success: true }, 200, { "Set-Cookie": sessionCookie(token) });
  }
  if (path === "/api/auth/logout" && request.method === "POST") {
    await setSetting(env.DB, "session_hash", "");
    await setSetting(env.DB, "session_expiry", "0");
    return json({ success: true }, 200, { "Set-Cookie": sessionCookie("", 0) });
  }
  if (!(await isAuthorized(request, env.DB))) return json({ error: "Sign in to continue." }, 401);

  if (path === "/api/state" && request.method === "GET") {
    const { results = [] } = await env.DB.prepare("SELECT id,name,uuid,route_key,protocol,active,created_at,traffic_limit,traffic_used FROM nova_profiles ORDER BY created_at DESC").all();
    const settings = await currentSettings(env.DB);
    const users = results.map((u) => ({
      ...u,
      active: Number(u.active) === 1,
      limit: Number(u.traffic_limit) || 0,
      used: Number(u.traffic_used) || 0,
      links: buildLinks(u, url.hostname, settings),
      subscription: `${url.origin}/sub/${u.route_key}`
    }));
    const total = users.length;
    const active = users.filter((u) => u.active).length;
    const totalBytes = users.reduce((sum, u) => sum + u.used, 0);
    const mb = totalBytes / (1024 * 1024);
    return json({
      host: url.hostname,
      settings,
      users,
      stats: { total, active, connections: runtimeStats.active, traffic: mb.toFixed(2) + " MB", trafficBytes: totalBytes, requests: runtimeStats.requests }
    });
  }

  if (path === "/api/users" && request.method === "POST") {
    const body = await readJson(request);
    const name = String(body.name || "").trim().slice(0, 32);
    const protocol = ["vless", "trojan", "both"].includes(body.protocol) ? body.protocol : "both";
    if (!name) return json({ error: "Profile name is required." }, 400);
    const id = typeof body.rid === "string" && /^[A-Za-z0-9-]{8,64}$/.test(body.rid) ? body.rid : crypto.randomUUID();
    const uuid = crypto.randomUUID();
    const routeKey = randomHex(6);
    const limitBytes = parseLimit(body.limitGb);
    try {
      await env.DB.prepare("INSERT INTO nova_profiles (id,name,uuid,route_key,protocol,active,created_at,traffic_limit,traffic_used) VALUES (?,?,?,?,?,1,?,?,0)")
        .bind(id, name, uuid, routeKey, protocol, Date.now(), limitBytes).run();
    } catch (error) {
      const msg = String(error && error.message || error);
      if (!/no such column/i.test(msg)) throw error;
      await env.DB.prepare("INSERT INTO nova_profiles (id,name,uuid,route_key,protocol,active,created_at) VALUES (?,?,?,?,?,1,?)")
        .bind(id, name, uuid, routeKey, protocol, Date.now()).run();
    }
    return json({ success: true, id, uuid, routeKey });
  }

  if (path.startsWith("/api/users/")) {
    let id = "";
    try { id = decodeURIComponent(path.slice("/api/users/".length)); } catch { return json({ error: "Invalid identifier." }, 400); }
    if (!id || id.length > 64) return json({ error: "Invalid identifier." }, 400);
    if (request.method === "DELETE") {
      await env.DB.prepare("DELETE FROM nova_profiles WHERE id = ?").bind(id).run();
      return json({ success: true });
    }
    if (request.method === "PATCH") {
      const body = await readJson(request);
      if (body.active !== undefined) {
        await env.DB.prepare("UPDATE nova_profiles SET active = ? WHERE id = ?").bind(body.active ? 1 : 0, id).run();
      }
      if (body.limitGb !== undefined) {
        await env.DB.prepare("UPDATE nova_profiles SET traffic_limit = ? WHERE id = ?").bind(parseLimit(body.limitGb), id).run();
      }
      if (body.resetUsage) {
        await env.DB.prepare("UPDATE nova_profiles SET traffic_used = 0 WHERE id = ?").bind(id).run();
      }
      if (body.name !== undefined) {
        const name = String(body.name || "").trim().slice(0, 32);
        if (!name) return json({ error: "Name cannot be empty." }, 400);
        await env.DB.prepare("UPDATE nova_profiles SET name = ? WHERE id = ?").bind(name, id).run();
      }
      return json({ success: true });
    }
  }

  if (path === "/api/settings" && request.method === "POST") {
    const body = await readJson(request);
    const edgeHosts = parseLines(body.edgeHosts).map(cleanEndpoint).filter(Boolean).join("\n");
    const ports = parsePorts(body.ports).join(",");
    const streamTag = safeTag(body.streamTag);
    await Promise.all([
      setSetting(env.DB, "edge_hosts", edgeHosts),
      setSetting(env.DB, "ports", ports),
      setSetting(env.DB, "stream_tag", streamTag)
    ]);
    return json({ success: true });
  }
  return json({ error: "API route not found." }, 404);
}

const MAX_LOGIN_FAILS = 8;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;

async function loginGuard(db, ip) {
  const key = "lf:" + (await sha256Hex(ip)).slice(0, 24);
  const raw = await getSetting(db, key, "");
  let count = 0;
  if (raw) {
    const [c, at] = raw.split(":");
    if (Date.now() - (Number(at) || 0) <= LOGIN_WINDOW_MS) count = Number(c) || 0;
  }
  return { key, count };
}

const DbService = Object.freeze({
  async ping(db) {
    if (!db) throw new Error("D1 binding DB is not configured.");
    const row = await db.prepare("SELECT 1 AS ok").first();
    return Number(row && row.ok) === 1;
  },
  ensureSchema,
  getSetting,
  setSetting,
  currentSettings
});

const AuthService = Object.freeze({
  passwordHash,
  verifyPassword,
  createSession,
  isAuthorized,
  loginGuard
});

const ProfileService = Object.freeze({
  buildLinks,
  handleSubscription,
  handleWebSocket
});

const ApiController = Object.freeze({ handle: handleApi });

const PanelController = Object.freeze({
  async handle(request, env) {
    const hasPassword = await DbService.getSetting(env.DB, "panel_password_hash");
    const mode = !hasPassword ? "setup" : (await AuthService.isAuthorized(request, env.DB) ? "dashboard" : "login");
    const html = mode === "dashboard" ? DASHBOARD_HTML : renderAuthPage(mode);
    return new Response(html, {
      headers: {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma": "no-cache",
        "Expires": "0"
      }
    });
  }
});

const Router = Object.freeze({
  async dispatch(request, env, ctx) {
    const url = new URL(request.url);
    const route = url.pathname.replace(/\/+$/, "") || "/";

    if (route === "/" || route === "/login") {
      return Response.redirect(new URL("/panel", url), 302);
    }

    if (!env || !env.DB) {
      if (route === "/health") {
        return json({ ok: false, panel: PANEL_NAME, d1: false, error: "D1 binding DB is not configured." }, 503);
      }
      return route.startsWith("/api/")
        ? json({ error: "D1 binding DB is not configured." }, 503)
        : new Response("D1 binding DB is not configured.", { status: 503 });
    }

    if (route === "/health") {
      const d1 = await DbService.ping(env.DB);
      return json({ ok: d1, panel: PANEL_NAME, d1, schema: "lazy", websocket: true }, d1 ? 200 : 503);
    }

    await DbService.ensureSchema(env.DB);

    if (url.pathname.startsWith("/stream/")) {
      const segments = url.pathname.split("/").filter(Boolean);
      const [stream, tag, routeKey] = segments;
      const currentTag = safeTag(await DbService.getSetting(env.DB, "stream_tag", DEFAULT_STREAM_TAG));
      if (stream !== "stream" || tag !== currentTag || !routeKey) {
        return new Response("Not Found", { status: 404 });
      }
      const user = await env.DB.prepare(
        "SELECT * FROM nova_profiles WHERE route_key = ? AND active = 1"
      ).bind(routeKey).first();
      if (!user) return new Response("Not Found", { status: 404 });
      if (Number(user.traffic_limit) > 0 && Number(user.traffic_used) >= Number(user.traffic_limit)) {
        return new Response("Quota exceeded", { status: 403 });
      }
      return ProfileService.handleWebSocket(request, env, ctx, user);
    }

    if (url.pathname.startsWith("/sub/")) {
      return ProfileService.handleSubscription(url, env);
    }
    if (url.pathname.startsWith("/api/")) {
      return ApiController.handle(request, url, env);
    }
    if (route === "/panel") {
      return PanelController.handle(request, env);
    }
    return new Response("Not Found", { status: 404 });
  }
});

function withSecurityHeaders(res, requestId = "") {
  if (res.status === 101) return res;
  const headers = new Headers(res.headers);
  if (requestId) headers.set("X-Request-ID", requestId);
  headers.set("X-Content-Type-Options", "nosniff");
  headers.set("Referrer-Policy", "no-referrer");
  headers.set("X-Frame-Options", "DENY");
  return new Response(res.body, { status: res.status, statusText: res.statusText, headers });
}

const WorkerRuntime = Object.freeze({
  async fetch(request, env, ctx) {
    let requestId = "unassigned";
    let url;
    try {
      requestId = randomHex(8);
      url = new URL(request.url);
      runtimeStats.requests++;
      const response = await Router.dispatch(request, env, ctx);
      return withSecurityHeaders(response, requestId);
    } catch (error) {
      const message = error && typeof error.message === "string"
        ? error.message
        : "Unknown runtime exception";
      console.error(JSON.stringify({
        event: "worker_exception",
        requestId,
        method: request.method,
        route: url.pathname.startsWith("/stream/") ? "/stream/:tag/:key"
          : url.pathname.startsWith("/sub/") ? "/sub/:key"
          : url.pathname,
        message,
        stack: error && error.stack ? String(error.stack).slice(0, 4000) : ""
      }));
      const path = url && url.pathname ? url.pathname : "/";
      const isApi = path.startsWith("/api/");
      const response = isApi
        ? json({ error: "INTERNAL_ERROR", requestId }, 500)
        : new Response("Internal Worker Error. Reference: " + requestId, {
            status: 500,
            headers: {
              "Content-Type": "text/plain; charset=utf-8",
              "Cache-Control": "no-store"
            }
          });
      return withSecurityHeaders(response, requestId);
    }
  }
});

export default WorkerRuntime;
