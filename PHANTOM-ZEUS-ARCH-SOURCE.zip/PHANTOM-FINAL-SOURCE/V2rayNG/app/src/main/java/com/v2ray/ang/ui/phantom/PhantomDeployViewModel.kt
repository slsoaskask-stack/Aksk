package com.v2ray.ang.ui.phantom

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.v2ray.ang.R
import com.v2ray.ang.handler.PhantomDeployer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class PhantomDeployUiState(
    val loading: Boolean = false,
    val error: String = "",
    val warning: String = "",
    val panelUrl: String = "",
    val setupKey: String = "",
    val account: String = ""
)

class PhantomDeployViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(
        PhantomDeployUiState(
            panelUrl = prefs.getString(KEY_URL, "").orEmpty(),
            setupKey = prefs.getString(KEY_SETUP, "").orEmpty(),
            account = prefs.getString(KEY_ACCOUNT, "").orEmpty()
        )
    )
    val state: StateFlow<PhantomDeployUiState> = _state.asStateFlow()

    fun build(rawToken: String) {
        if (_state.value.loading) return
        val token = rawToken.replace(Regex("\\s+"), "").removePrefix("Bearer")
        if (token.length < 20) {
            _state.update { it.copy(error = str(R.string.phantom_err_token)) }
            return
        }
        _state.update { it.copy(loading = true, error = "", warning = "") }
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                PhantomDeployer(getApplication()).deploy(token)
            }
            if (result.ok) {
                prefs.edit()
                    .putString(KEY_URL, result.panelUrl)
                    .putString(KEY_SETUP, result.setupKey)
                    .putString(KEY_ACCOUNT, result.account)
                    .apply()
                _state.update {
                    it.copy(
                        loading = false,
                        error = "",
                        warning = result.warning,
                        panelUrl = result.panelUrl,
                        setupKey = result.setupKey,
                        account = result.account
                    )
                }
            } else {
                val message = when (result.failure) {
                    PhantomDeployer.Failure.NO_ACCOUNT -> str(R.string.phantom_err_no_account)
                    PhantomDeployer.Failure.NO_SUBDOMAIN -> str(R.string.phantom_err_no_subdomain)
                    PhantomDeployer.Failure.NETWORK -> str(R.string.phantom_err_network)
                    PhantomDeployer.Failure.AUTH -> str(R.string.phantom_err_auth)
                    else -> result.detail.ifBlank { str(R.string.toast_failure) }
                }
                _state.update { it.copy(loading = false, error = message, warning = "") }
            }
        }
    }

    private fun str(id: Int): String = getApplication<Application>().getString(id)

    private companion object {
        const val PREFS = "phantom"
        const val KEY_URL = "panel_url"
        const val KEY_SETUP = "setup_key"
        const val KEY_ACCOUNT = "account"
    }
}
