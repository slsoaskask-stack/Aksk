package com.v2ray.ang.ui.phantom

import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v2ray.ang.R
import com.v2ray.ang.extension.toast
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.util.Utils

/** Builds the Phantom panel (Worker + D1) on the user's Cloudflare account from an API token. */
class PhantomDeployActivity : BaseComponentActivity() {

    private val viewModel: PhantomDeployViewModel by viewModels()

    @Composable
    override fun ScreenContent() {
        val state by viewModel.state.collectAsStateWithLifecycle()
        PhantomDeployScreen(
            state = state,
            onBack = { finish() },
            onBuild = { viewModel.build(it) },
            onOpen = { openPanel(state.panelUrl, state.setupKey) },
            onCopy = {
                Utils.setClipboard(this, state.panelUrl)
                toast(R.string.toast_success)
            }
        )
    }

    private fun openPanel(url: String, setupKey: String) {
        if (url.isBlank()) return
        // The setup key travels in the URL fragment: the browser never sends it to the server,
        // only the panel's setup page reads it.
        val target = if (setupKey.isNotBlank()) "$url#k=$setupKey" else url
        try {
            startActivity(Intent(Intent.ACTION_VIEW, target.toUri()))
        } catch (_: ActivityNotFoundException) {
            toast(R.string.phantom_no_browser)
        }
    }
}

@Composable
private fun PhantomDeployScreen(
    state: PhantomDeployUiState,
    onBack: () -> Unit,
    onBuild: (String) -> Unit,
    onOpen: () -> Unit,
    onCopy: () -> Unit
) {
    var token by rememberSaveable { mutableStateOf("") }
    var showToken by rememberSaveable { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            AppTopBar(
                title = stringResource(R.string.phantom_title),
                onBackClick = onBack,
                isLoading = state.loading
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .consumeWindowInsets(innerPadding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                painter = painterResource(R.drawable.phantom_logo),
                contentDescription = null,
                modifier = Modifier
                    .size(96.dp)
                    .align(Alignment.CenterHorizontally)
            )

            Text(
                text = stringResource(R.string.phantom_subtitle),
                style = MaterialTheme.typography.bodyMedium
            )

            OutlinedTextField(
                value = token,
                onValueChange = { token = it },
                label = { Text(stringResource(R.string.phantom_token_label)) },
                singleLine = true,
                enabled = !state.loading,
                visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            Row(modifier = Modifier.fillMaxWidth()) {
                TextButton(onClick = { showToken = !showToken }) {
                    Text(stringResource(if (showToken) R.string.phantom_token_hide else R.string.phantom_token_show))
                }
            }

            if (state.error.isNotBlank()) {
                Text(
                    text = state.error,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            if (state.warning.isNotBlank()) {
                Text(
                    text = state.warning,
                    color = MaterialTheme.colorScheme.tertiary,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Button(
                onClick = { onBuild(token) },
                enabled = !state.loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(stringResource(if (state.loading) R.string.phantom_building else R.string.phantom_build))
            }

            if (state.panelUrl.isNotBlank()) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = if (state.account.isBlank()) {
                                stringResource(R.string.phantom_built_generic)
                            } else {
                                stringResource(R.string.phantom_built_on, state.account)
                            },
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = state.panelUrl,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Button(onClick = onOpen, modifier = Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.phantom_open_panel))
                        }
                        OutlinedButton(onClick = onCopy, modifier = Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.phantom_copy_link))
                        }
                        Text(
                            text = stringResource(R.string.phantom_after_build),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            Text(
                text = stringResource(R.string.phantom_help_title),
                style = MaterialTheme.typography.titleSmall
            )
            Text(
                text = stringResource(R.string.phantom_help_body),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
