# R8 / ProGuard for the Phantom release APK.
# Class and method names in app logic are renamed. Gson models, JNI entry
# points, and the gomobile Xray bridge keep their names so the app still runs.
# Line numbers stay, but source file names are erased. Ship mapping.txt privately.

-keepattributes Signature,InnerClasses,EnclosingMethod,Exceptions,AnnotationDefault
-keepattributes RuntimeVisibleAnnotations,RuntimeVisibleParameterAnnotations
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# HEV tun2socks JNI. The .so looks up these exact class and method names.
-keep class com.v2ray.ang.service.TProxyService {
    native <methods>;
}

# gomobile / Xray. Renaming these breaks the prebuilt libv2ray AAR.
-keep class libv2ray.** { *; }
-keep class go.** { *; }
-dontwarn libv2ray.**
-dontwarn go.**

# Gson reads field names and reflective constructors. Keep the model shape,
# not the rest of the app.
-keep class com.v2ray.ang.dto.** { <init>(...); <fields>; }
-keep class com.v2ray.ang.dto.**$* { <init>(...); <fields>; }

-keepclassmembers enum com.v2ray.ang.enums.** { *; }
-keepclassmembers enum com.v2ray.ang.dto.** { *; }
-keepclassmembers enum com.v2ray.ang.dto.**$* { *; }

-keepclassmembers class * implements android.os.Parcelable {
    public static final ** CREATOR;
}

# Workers and manifest components are kept by the Android Gradle Plugin.
-keep class * extends androidx.work.ListenableWorker { <init>(...); }

-dontwarn javax.annotation.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn com.tencent.mmkv.**
