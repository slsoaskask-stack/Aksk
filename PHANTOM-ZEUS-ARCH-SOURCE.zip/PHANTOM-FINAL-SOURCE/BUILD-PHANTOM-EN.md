# Build Phantom 2.4.4 for armeabi-v7a

## Repository setup

1. Copy `phantom-zip-build.yml` into `.github/workflows/phantom-zip-build.yml` in your GitHub repository.
2. Put `PHANTOM-ZEUS-ARCH-SOURCE.zip` in the repository root without renaming it.
3. Commit both files. The workflow extracts the ZIP and builds the Android release.

## Persistent release signing

Create or recover the exact release keystore used by the APK already installed on your device. Do not generate a different key for an update. Configure these GitHub Actions Secrets:

- `APP_KEYSTORE_BASE64`
- `APP_KEYSTORE_PASSWORD`
- `APP_KEYSTORE_ALIAS`
- `APP_KEY_PASSWORD`

On Windows PowerShell, encode an existing keystore with:

```powershell
$bytes = [System.IO.File]::ReadAllBytes("phantom-release.jks")
[Convert]::ToBase64String($bytes) | Set-Clipboard
```

Paste the Base64 value into `APP_KEYSTORE_BASE64`. Add the other three values as separate Secrets. Never commit the `.jks` file or its passwords.

If an earlier build used a temporary keystore, recover that exact private keystore artifact from the same GitHub Actions run and use it here. If it is unavailable, Android will not accept a new signature as an update to that installed app. A clean reinstall may be required and can remove local app preferences. The Cloudflare Worker and D1 data are separate from the APK signature.

## Run the build

1. Open the repository's **Actions** tab.
2. Select **Phantom ZEUS-Architecture Release Build (from ZIP)**.
3. Choose **Run workflow**.
4. After success, download `Phantom-2.4.4-ZEUS-Architecture-Android-armeabi-v7a-Release-APK`.

The workflow validates the readable Worker, minifies it with a pinned Terser version, obfuscates it with `javascript-obfuscator` using the `browser-no-eval` target, syntax-checks the generated module, and runs the smoke tests against the obfuscated output. It then prepares the native HEV and Xray libraries, builds the Android release, and verifies the embedded Worker and R8 mapping.

## Deployment diagnostics

The app probes `/health` and `/panel` after deploying the Worker. A Cloudflare-generated 1101 response is reported separately and directs you to **Workers & Pages → your Worker → Logs**. The Worker also emits a structured `worker_exception` log event with a request ID, route, message, and stack trace. Credentials, cookies, and setup keys are not intentionally written to logs.
