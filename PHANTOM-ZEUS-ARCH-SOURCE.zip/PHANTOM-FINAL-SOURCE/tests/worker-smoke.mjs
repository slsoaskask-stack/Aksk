import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";

const here = resolve(fileURLToPath(new URL("..", import.meta.url)));
const workerPath = process.env.PHANTOM_WORKER_SOURCE
  ? resolve(process.env.PHANTOM_WORKER_SOURCE)
  : resolve(here, "V2rayNG/app/src/main/assets/phantom-worker.js");
let source = await readFile(workerPath, "utf8");
let socketBinding = "connect";
source = source.replace(
  /import\s*\{\s*connect(?:\s+as\s+([A-Za-z_$][\w$]*))?\s*\}\s*from\s*["']cloudflare:sockets["']\s*;?/,
  (_statement, localName) => {
    socketBinding = localName || "connect";
    return `const ${socketBinding} = () => { throw new Error("TCP sockets are not available in this local smoke test"); };`;
  }
);
assert.match(source, new RegExp(`const\\s+${socketBinding}\\s*=`), "Cloudflare socket import must be replaced by the test stub");
assert.notEqual(source, "", "Worker source must not be empty");
const moduleUrl = `data:text/javascript;base64,${Buffer.from(source).toString("base64")}`;
const { default: worker } = await import(moduleUrl);

const sqlite = new DatabaseSync(":memory:");
const DB = {
  prepare(sql) {
    let values = [];
    return {
      bind(...args) { values = args; return this; },
      async run() { return sqlite.prepare(sql).run(...values); },
      async all() { return { results: sqlite.prepare(sql).all(...values) }; },
      async first() { return sqlite.prepare(sql).get(...values) ?? null; }
    };
  }
};
const env = { DB, SETUP_KEY: "phantom-local-smoke-key" };
const context = {};
async function call(path, options = {}, runtimeEnv = env) {
  const headers = new Headers(options.headers || {});
  if (options.body !== undefined) headers.set("Content-Type", "application/json");
  const request = new Request(`https://phantom-smoke.test${path}`, {
    method: options.method || "GET",
    headers,
    body: options.body === undefined ? undefined : JSON.stringify(options.body)
  });
  return worker.fetch(request, runtimeEnv, context);
}

const healthWithoutDb = await call("/health", {}, {});
assert.equal(healthWithoutDb.status, 503, "health must report a missing D1 binding");
const brokenDb = { prepare() { throw new Error("simulated D1 failure"); } };
const priorConsoleError = console.error;
console.error = () => {};
let runtimeFailure;
try {
  runtimeFailure = await call("/health", {}, { DB: brokenDb });
} finally {
  console.error = priorConsoleError;
}
assert.equal(runtimeFailure.status, 500, "runtime exceptions must become controlled HTTP errors");
assert.ok(runtimeFailure.headers.get("X-Request-ID"), "runtime errors must be traceable by request ID");
assert.match(await runtimeFailure.text(), /Internal Worker Error/);
const health = await call("/health");
assert.equal(health.status, 200);
assert.equal((await health.json()).d1, true);
assert.ok(health.headers.get("X-Request-ID"));

const panelSetup = await call("/panel");
assert.equal(panelSetup.status, 200);
const setupHtml = await panelSetup.text();
assert.match(setupHtml, /id="auth"/);
assert.match(setupHtml, /lang="en"/);

const setup = await call("/api/auth/setup", {
  method: "POST",
  body: { password: "Smoke-Test-Password-99", k: env.SETUP_KEY }
});
assert.equal(setup.status, 200);
const cookie = setup.headers.get("Set-Cookie")?.split(";")[0];
assert.ok(cookie, "setup should create a session cookie");

const dashboard = await call("/panel", { headers: { Cookie: cookie } });
assert.equal(dashboard.status, 200);
assert.match(await dashboard.text(), /PHANTOM \| Control Panel/);

const unauthorized = await call("/api/state");
assert.equal(unauthorized.status, 401);

const settingsSaved = await call("/api/settings", {
  method: "POST",
  headers: { Cookie: cookie },
  body: { edgeHosts: "edge.example.net", ports: "443,2053", streamTag: "PHANTOM_TEST" }
});
assert.equal(settingsSaved.status, 200);

const stateBefore = await call("/api/state", { headers: { Cookie: cookie } });
assert.equal(stateBefore.status, 200);
assert.equal((await stateBefore.json()).stats.total, 0);

const created = await call("/api/users", {
  method: "POST",
  headers: { Cookie: cookie },
  body: { name: "Smoke Profile", protocol: "both", limitGb: 0 }
});
assert.equal(created.status, 200);
const profile = await created.json();
assert.ok(profile.id && profile.routeKey && profile.uuid);

const stateAfter = await call("/api/state", { headers: { Cookie: cookie } });
const state = await stateAfter.json();
assert.equal(state.stats.total, 1);
assert.equal(state.users[0].name, "Smoke Profile");
assert.equal(state.users[0].active, true);
assert.ok(state.settings.edgeHosts.includes("edge.example.net"));

const updated = await call(`/api/users/${encodeURIComponent(profile.id)}`, {
  method: "PATCH",
  headers: { Cookie: cookie },
  body: { active: false, limitGb: 2 }
});
assert.equal(updated.status, 200);
const inactiveState = await call("/api/state", { headers: { Cookie: cookie } });
const inactiveProfile = (await inactiveState.json()).users[0];
assert.equal(inactiveProfile.active, false);
assert.equal(inactiveProfile.limit, 2 * 1024 * 1024 * 1024);
const inactiveSub = await call(`/sub/${profile.routeKey}`);
assert.equal(inactiveSub.status, 404);

const reactivated = await call(`/api/users/${encodeURIComponent(profile.id)}`, {
  method: "PATCH",
  headers: { Cookie: cookie },
  body: { active: true, resetUsage: true }
});
assert.equal(reactivated.status, 200);

const sub = await call(`/sub/${profile.routeKey}`);
assert.equal(sub.status, 200);
const subscription = atob(await sub.text());
assert.match(subscription, /vless:\/\//);
assert.match(subscription, /trojan:\/\//);
assert.match(subscription, /edge\.example\.net:443/);
assert.match(subscription, /PHANTOM_TEST/);

const deleted = await call(`/api/users/${encodeURIComponent(profile.id)}`, {
  method: "DELETE",
  headers: { Cookie: cookie }
});
assert.equal(deleted.status, 200);
const stateAfterDelete = await call("/api/state", { headers: { Cookie: cookie } });
assert.equal((await stateAfterDelete.json()).stats.total, 0);
const logout = await call("/api/auth/logout", { method: "POST", headers: { Cookie: cookie }, body: {} });
assert.equal(logout.status, 200);
const afterLogout = await call("/api/state", { headers: { Cookie: cookie } });
assert.equal(afterLogout.status, 401);

console.log("Worker smoke tests passed: health, setup, session authorization, panel, settings, profile CRUD, subscription, logout.");
