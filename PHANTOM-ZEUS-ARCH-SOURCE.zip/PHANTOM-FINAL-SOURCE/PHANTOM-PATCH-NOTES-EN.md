# Phantom 2.4.4 patch notes

- The Worker entry path redirects to `/panel`.
- App deployment performs live `/health` and `/panel` probes.
- Health checks are non-mutating and separate D1 connectivity from schema migrations.
- Worker code is split into database, authentication, profile, API, panel, router, and runtime responsibilities.
- Runtime errors receive request IDs and structured Cloudflare log output.
- Worker UI and deployment diagnostic strings are English-only.
- Release output is minified and statically obfuscated using a no-eval target.
- Smoke tests are run against the obfuscated Worker during CI.
- Release signing now requires a persistent keystore; the app package identity remains unchanged.
- Android version: `2.4.4` (`versionCode 764`).

The local smoke suite passes. Live Cloudflare, D1, WebSocket/TCP, and Android device validation remain release-time checks.
