# HEV and GeoIP startup troubleshooting

## HEV library loading

Error example:

```text
java.lang.UnsatisfiedLinkError: dlopen failed: library "libhev-socks5-tunnel.so" not found
```

This means the installed APK does not contain the HEV native library for the device ABI. The VPN service may fail before the Xray connection starts.

The project checks whether the HEV library can be loaded before creating the VPN configuration and can fall back to the Xray TUN path. The `armeabi-v7a` build workflow compiles the pinned HEV source for that ABI and verifies both required shared libraries inside the APK.

## Missing GeoIP data file

Error example:

```text
failed to open geoip-only-cn-private.dat
```

This can occur when a routing rule references an external GeoIP data file that is not present in a fresh installation. The project now checks whether the required asset exists and is non-empty before converting the rule to a file-backed reference. Otherwise, it keeps the built-in `geoip:private` and `geoip:cn` rules.

## Validation limit

The source and workflow can verify native-library packaging, but actual VPN connection behavior must be tested on a device with a valid profile. A successful APK build alone does not prove that a particular remote endpoint is reachable.
