# Phantom 2.4.4 — Source and release notes

## Runtime changes

- `/` and `/login` redirect to `/panel`.
- The deployer checks `/health` and `/panel` through the public `workers.dev` hostname instead of treating a successful Cloudflare API upload as proof that the panel is ready.
- Worker and deployment diagnostics are English-only.
- The release workflow creates one obfuscated Worker artifact from the sole source file at `V2rayNG/app/src/main/assets/phantom-worker.js`; there is no checked-in stale release copy to override it.
- The panel retains its dark cyan/indigo visual identity and uses English labels and messages.
- `versionCode` is now `764`; `versionName` is `2.4.4`. The Android `applicationId` remains `com.phantom.client`.

## Worker architecture

The single-module Worker is organized into explicit service and controller boundaries:

- `DbService`: D1 connectivity, schema readiness, settings reads/writes.
- `AuthService`: password hashing, session handling, authorization, login throttling.
- `ProfileService`: link construction, subscription output, WebSocket handling.
- `ApiController`: management API routes.
- `PanelController`: setup, sign-in, and dashboard rendering.
- `Router`: deterministic HTTP dispatch.
- `WorkerRuntime`: centralized exception handling, request IDs, structured diagnostics, and response security headers.

Existing D1 table names and public routes are preserved for compatibility: `/panel`, `/health`, `/api/...`, `/sub/...`, and `/stream/...`. Database schema initialization is lazy; `/health` performs a non-mutating `SELECT 1` probe and does not run migrations. Panel/API routes initialize the schema before use.

## Obfuscation and runtime compatibility

The release pipeline uses Terser followed by `javascript-obfuscator` with `target: browser-no-eval`. It does not install an encoded source string and execute it through `new Function()` or `eval()` at Worker startup. That is intentional because Cloudflare Workers restrict dynamic code generation by default. Static obfuscation increases the effort required to inspect the delivered artifact, but it is not encryption and is not a substitute for server-side secrets or access controls.

The deployed Worker uses `compatibility_date: 2026-11-15`.

## Signing and upgrades

The release workflow requires a persistent keystore supplied through GitHub Actions Secrets. It no longer generates a new temporary signing key on every run. To update an already-installed build, use exactly the same keystore that signed it. Keep the keystore and passwords private.

## License and distribution

The Android base project is GPL-3.0. Preserve all notices and satisfy the license's corresponding-source obligations when distributing a modified build. Obfuscation does not remove those obligations. ZEUS-specific implementation code is not copied into this Worker; the organization here uses independent implementations of common software architecture concepts such as routing, storage, authentication, and controllers.

## Test status

The readable Worker passed `node --check` and `tests/worker-smoke.mjs` against an in-memory SQLite adapter. The smoke suite covers D1 health, setup, session authorization, panel rendering, settings, profile create/update/delete, subscription output, logout, and controlled exception responses. The GitHub Actions workflow is configured to run those tests against the obfuscated output as well.

A live Cloudflare deployment, real D1 account, real TCP socket connection, real WebSocket tunnel, and complete Android APK build have not been executed in this environment. A successful local smoke test does not prove that a deployed Worker will be error-free; inspect Cloudflare Logs for any remaining 1101 exception.
