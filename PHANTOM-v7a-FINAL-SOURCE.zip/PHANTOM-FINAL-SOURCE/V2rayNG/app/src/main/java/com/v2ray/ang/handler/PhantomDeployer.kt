package com.v2ray.ang.handler

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

/**
 * Creates the Phantom panel on the user's own Cloudflare account:
 * a D1 database plus a Worker script, then enables the workers.dev route.
 * The API token is only held in memory for the duration of the call.
 */
class PhantomDeployer(private val context: Context) {

    enum class Failure { NO_ACCOUNT, NO_SUBDOMAIN, NETWORK, AUTH, OTHER }

    data class Result(
        val ok: Boolean,
        val panelUrl: String = "",
        val account: String = "",
        val setupKey: String = "",
        val failure: Failure? = null,
        val detail: String = ""
    )

    private class ApiException(val code: Int, message: String) : Exception(message)

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    fun deploy(token: String): Result {
        return try {
            val accounts = getJsonArray(token, "/accounts")
            if (accounts.length() == 0) return Result(false, failure = Failure.NO_ACCOUNT)
            val account = accounts.getJSONObject(0)
            val accountId = account.getString("id")
            val accountName = account.optString("name", accountId)

            val databases = getJsonArray(token, "/accounts/$accountId/d1/database")
            var databaseId: String? = null
            for (i in 0 until databases.length()) {
                val db = databases.getJSONObject(i)
                if (db.optString("name") == DB_NAME) {
                    databaseId = db.getString("uuid")
                    break
                }
            }
            if (databaseId == null) {
                val created = postJson(token, "/accounts/$accountId/d1/database", JSONObject().put("name", DB_NAME))
                databaseId = created.getString("uuid")
            }

            // One-time setup key: only the person who opens the panel from this app can set the first password.
            val setupKey = newSetupKey()

            val workerSource = context.assets.open(ASSET).bufferedReader().use { it.readText() }
            val metadata = JSONObject()
                .put("main_module", "worker.js")
                .put("compatibility_date", "2024-12-01")
                .put(
                    "bindings",
                    JSONArray()
                        .put(
                            JSONObject()
                                .put("type", "d1")
                                .put("name", "DB")
                                .put("id", databaseId)
                                .put("database_id", databaseId)
                        )
                        .put(
                            JSONObject()
                                .put("type", "secret_text")
                                .put("name", "SETUP_KEY")
                                .put("text", setupKey)
                        )
                )

            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart(
                    "metadata",
                    null,
                    metadata.toString().toRequestBody("application/json".toMediaType())
                )
                .addFormDataPart(
                    "worker.js",
                    "worker.js",
                    workerSource.toRequestBody("application/javascript+module".toMediaType())
                )
                .build()

            request(token, "/accounts/$accountId/workers/scripts/$SCRIPT", "PUT", body)

            val subdomain = try {
                getJsonObject(token, "/accounts/$accountId/workers/subdomain").optString("subdomain", "")
            } catch (_: Exception) {
                ""
            }
            if (subdomain.isBlank()) return Result(false, failure = Failure.NO_SUBDOMAIN)

            postJson(
                token,
                "/accounts/$accountId/workers/scripts/$SCRIPT/subdomain",
                JSONObject().put("enabled", true)
            )

            Result(
                ok = true,
                panelUrl = "https://$SCRIPT.$subdomain.workers.dev/panel",
                account = accountName,
                setupKey = setupKey
            )
        } catch (e: ApiException) {
            if (e.code == 401 || e.code == 403) {
                Result(false, failure = Failure.AUTH)
            } else {
                Result(false, failure = Failure.OTHER, detail = (e.message ?: "").take(240))
            }
        } catch (e: IOException) {
            Result(false, failure = Failure.NETWORK)
        } catch (e: Exception) {
            Result(false, failure = Failure.OTHER, detail = (e.message ?: "").take(240))
        }
    }

    private fun newSetupKey(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun getJsonArray(token: String, path: String): JSONArray =
        request(token, path, "GET") as? JSONArray ?: JSONArray()

    private fun getJsonObject(token: String, path: String): JSONObject =
        request(token, path, "GET") as? JSONObject ?: JSONObject()

    private fun postJson(token: String, path: String, body: JSONObject): JSONObject =
        request(token, path, "POST", body.toString().toRequestBody(JSON)) as? JSONObject ?: JSONObject()

    private fun request(token: String, path: String, method: String, body: RequestBody? = null): Any {
        val req = Request.Builder()
            .url("$BASE$path")
            .header("Authorization", "Bearer $token")
            .method(method, body)
            .build()

        client.newCall(req).execute().use { response ->
            val text = response.body.string()
            val json = try {
                JSONObject(text)
            } catch (_: Exception) {
                throw ApiException(response.code, text.take(180).ifBlank { "HTTP ${response.code}" })
            }
            if (!response.isSuccessful || !json.optBoolean("success", false)) {
                val message = json.optJSONArray("errors")
                    ?.optJSONObject(0)
                    ?.optString("message")
                    ?.ifBlank { null }
                    ?: text.take(180).ifBlank { "HTTP ${response.code}" }
                throw ApiException(response.code, message)
            }
            return json.opt("result") ?: JSONObject()
        }
    }

    private companion object {
        const val BASE = "https://api.cloudflare.com/client/v4"
        const val SCRIPT = "phantom-panel"
        const val DB_NAME = "phantom-panel"
        const val ASSET = "phantom-worker.js"
        val JSON = "application/json; charset=utf-8".toMediaType()
    }
}
