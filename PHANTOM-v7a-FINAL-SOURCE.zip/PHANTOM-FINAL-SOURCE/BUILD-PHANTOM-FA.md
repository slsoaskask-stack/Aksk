# راهنمای بیلد Phantom برای گوشی armeabi-v7a

1. ZIP را روی کامپیوتر Extract کن؛ خود ZIP را به‌صورت یک فایل در GitHub آپلود نکن.
2. همهٔ محتویات پوشه، از جمله پوشهٔ مخفی `.github`، باید در ریشهٔ مخزن قرار بگیرند.
3. تغییرات را Commit کن و وارد تب Actions شو.
4. Workflow با نام **Phantom Android Debug (armeabi-v7a)** را انتخاب کن و **Run workflow** بزن.
5. پس از موفقیت، Artifact با نام `Phantom-Android-armeabi-v7a-Debug-APK` را دانلود کن و APK داخل آن را نصب کن.

این Workflow فقط ABI `armeabi-v7a` را می‌سازد. سورس HEV را از commit ثابت `64cc609f945253b0e9ebc56317d544268f3c68c1` دریافت می‌کند، دو کتابخانهٔ native را کامپایل می‌کند و پیش از بیلد و پس از ساخت APK وجود آن‌ها را بررسی می‌کند. AAR هستهٔ Xray نیز به‌صورت نسخهٔ ثابت `v26.9.9` دریافت می‌شود و وجود فایل native مربوط به `armeabi-v7a` در آن کنترل می‌شود.

## رفع خطاهای دیده‌شده در Logcat

- `libhev-socks5-tunnel.so not found`: در این Workflow وجود `lib/armeabi-v7a/libhev-socks5-tunnel.so` و `lib/armeabi-v7a/libhevsockstun.so` داخل APK شرط موفقیت است.
- `geoip-only-cn-private.dat` not found: تبدیل `geoip:cn` و `geoip:private` به `ext:` فقط وقتی انجام می‌شود که فایل اختیاری واقعاً دانلود و در پوشهٔ assets موجود باشد؛ در نصب تازه، قواعد داخلی Xray باقی می‌مانند.

## نصب

شناسهٔ Play Store flavor برابر `com.phantom.client` است؛ می‌تواند کنار نسخهٔ اصلی v2rayNG نصب شود. داده‌ها و پروفایل‌های نسخهٔ قبلی خودکار منتقل نمی‌شوند؛ قبل از حذف نسخهٔ قبلی از پروفایل‌ها Backup/Export بگیر. Debug APK با کلید دیباگ همان اجرای GitHub Actions امضا می‌شود و برای به‌روزرسانی نسخه‌ای با امضای متفاوت، ممکن است لازم شود نسخهٔ قبلی Phantom حذف شود.

## نکات مهم

- این Workflow یک APK دیباگ می‌سازد، نه Release امضاشده برای انتشار فروشگاهی.
- این محیط Android SDK/NDK کامل و دسترسی لازم برای دانلود Gradle ندارد؛ بنابراین APK را اینجا کامپایل یا روی گوشی آزمایش نکرده‌ام. کنترل ABI و وجود native library داخل APK در GitHub Actions انجام می‌شود.
- مبهم‌سازی R8 در این Debug build فعال نیست. برای انتشار تجاری باید جداگانه Release build و تست JNI انجام شود. چون پروژه بر پایهٔ v2rayNG با GPL-3.0 است، انتشار نسخهٔ تغییریافته مستلزم رعایت GPL و ارائهٔ سورس متناظر نیز هست.
