# اصلاح خطای HEV و فایل geoip در Phantom

## خطای اول در Logcat

`java.lang.UnsatisfiedLinkError: dlopen failed: library "libhev-socks5-tunnel.so" not found`

این خطا یعنی APK نصب‌شده کتابخانهٔ native مربوط به HEV را برای ABI گوشی نداشته است. سرویس VPN پیش از اتصال به سرور کرش می‌کرد.

## اصلاح در سورس

- `CoreVpnService` پیش از ساخت VPN بررسی می‌کند کتابخانهٔ HEV قابل بارگذاری هست یا نه؛ اگر نباشد، قبل از ساخت تنظیمات Xray به Xray TUN برمی‌گردد.
- workflow مخصوص گوشی `armeabi-v7a`، سورس HEV را از commit ثابت می‌گیرد، فقط ABI لازم را می‌سازد و وجود هر دو کتابخانهٔ HEV را داخل APK کنترل می‌کند.

## خطای دوم در تصویر

`failed to open geoip-only-cn-private.dat`

این خطا از یک قانون مسیریابی می‌آمد که `geoip:private` یا `geoip:cn` را به فایل خارجی `geoip-only-cn-private.dat` تبدیل می‌کرد، در حالی که آن فایل در نصب تازه وجود نداشت. حالا این تبدیل فقط وقتی انجام می‌شود که فایل واقعاً در پوشهٔ assets کاربر موجود و غیرخالی باشد؛ در غیر این صورت قواعد داخلی `geoip:private` و `geoip:cn` باقی می‌مانند.

## روش ساخت

از workflow با نام `Phantom Android Debug (armeabi-v7a)` استفاده کن. راهنمای گام‌به‌گام در `BUILD-PHANTOM-FA.md` است. پس از موفقیت اجرا، Artifact با نام `Phantom-Android-armeabi-v7a-Debug-APK` را بگیر.

## محدودیت تست

این محیط Android SDK/NDK لازم برای ساخت APK را ندارد؛ بنابراین من APK را اینجا کامپایل و روی گوشی آزمایش نکرده‌ام. workflow وجود کتابخانه‌های native را داخل APK کنترل می‌کند، اما موفقیت اتصال به یک سرور مشخص فقط روی گوشی و با پروفایل معتبر قابل تأیید است.
