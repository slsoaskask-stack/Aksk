# راهنمای ساخت Phantom 2.4.3 برای armeabi-v7a

## آماده‌سازی مخزن

1. فایل Workflow مستقل `phantom-zip-build.yml` را در مسیر `.github/workflows/phantom-zip-build.yml` مخزن GitHub قرار بده.
2. فایل سورس `PHANTOM-v8.0-SOURCE.zip` را بدون تغییر نام در ریشهٔ مخزن قرار بده.
3. در همین مخزن هر دو فایل را Commit کن؛ Workflow از ZIP استخراج می‌کند و پوشهٔ سورس را برای Release می‌سازد.

## امضای Release

در GitHub → Settings → Secrets and variables → Actions این Secretها را برای Keystore دائمی تنظیم کن:

- `APP_KEYSTORE_BASE64`
- `APP_KEYSTORE_PASSWORD`
- `APP_KEYSTORE_ALIAS`
- `APP_KEY_PASSWORD`

در نبود Secretها Workflow کلید موقت می‌سازد و آن را به‌صورت Artifact با نام `Phantom-signing-keystore-KEEP-PRIVATE` نگه می‌دارد؛ این Artifact و `Phantom-R8-mapping-KEEP-PRIVATE` را عمومی نکن. برای انتشار واقعی و دریافت به‌روزرسانی، Keystore دائمی و ثابت ضروری است.

## اجرای بیلد

1. به تب Actions برو.
2. Workflow با نام **Phantom v8.0 Release Build (from ZIP)** را انتخاب کن.
3. **Run workflow** را بزن.
4. پس از موفقیت، Artifact `Phantom-2.4.3-Android-armeabi-v7a-Release-APK` را دریافت کن.

Workflow سورس HEV را از commit ثابت دریافت می‌کند، AAR مشخص Xray را کنترل می‌کند، Worker را با Terser minify/mangle می‌کند، Worker جاسازی‌شده را از APK بیرون می‌کشد و syntax و مسیرهای اصلی آن را بررسی می‌کند. سپس وجود کتابخانه‌های native و فعال‌بودن R8 را اعتبارسنجی می‌کند.

## پنل پس از استقرار

اپ بعد از انتشار Worker، ابتدا `/health` و سپس `/panel` را از دامنهٔ `workers.dev` بررسی می‌کند. اگر ساخت Worker و D1 در API موفق باشد اما صفحه یا اتصال دیتابیس آماده نباشد، اپ هشدار حاوی نشانی دقیق پنل و دلیل آخرین پاسخ را نشان می‌دهد.

برای توضیح معماری، محدودیت‌ها و مجوزها فایل `PHANTOM-FINAL-FA.md` را بخوان.
