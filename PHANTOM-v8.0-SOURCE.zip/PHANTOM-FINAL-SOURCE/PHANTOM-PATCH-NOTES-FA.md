# یادداشت تغییرات Phantom 2.4.3

- مسیر `/` در Worker به `/panel` هدایت می‌شود.
- پس از آپلود، اپ آمادگی واقعی `/health` و صفحهٔ HTML مسیر `/panel` را بررسی می‌کند و در صورت شکست، هشدار دقیق نشان می‌دهد.
- فایل تکراری و قدیمی release از سورس حذف شد؛ منبع اصلی فقط `src/main/assets/phantom-worker.js` است.
- Workflow، خروجی Release را با Terser minify/mangle می‌کند و Syntax/feature check روی فایل نهایی داخل APK انجام می‌دهد.
- صفحهٔ ورود و داشبورد از یک هویت بصری PHANTOM با تم تیرهٔ cyan/indigo استفاده می‌کنند. نشان API/D1 وضعیت واقعی بارگیری داده‌ها را بازتاب می‌دهد.
- نام برند و مقدار پیش‌فرض stream tag به PHANTOM تغییر کرد؛ جدول‌ها و تنظیمات موجود D1 برای سازگاری حفظ می‌شوند.
- `versionCode=763` و `versionName=2.4.3`.
- R8 و shrinkResources در تنظیمات Release از قبل فعال بودند؛ Workflow فعال‌بودن R8 را با mapping بررسی می‌کند.

## نکتهٔ انتشار

Minify و obfuscation جایگزین نگهداری امن Secretها یا ارائهٔ سورس متناظر GPL-3.0 نیستند. Keystore و R8 mapping را خصوصی نگه دار. برای ارتقا از همان Keystore دائمی استفاده کن.

## تست

Syntax فایل Worker با Node و مسیرهای `/`، `/health`، ساخت رمز، صفحهٔ داشبورد احرازشده و `/api/state` با D1 ساختگی بررسی شدند. Workflow نیز از نظر YAML و نحو Bash بررسی شده است. بیلد APK، اجرای واقعی GitHub Actions و استقرار زندهٔ Cloudflare در این محیط اجرا نشده‌اند؛ Workflow این کنترل‌ها را در زمان بیلد/نصب انجام می‌دهد.
